
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <R.h>
#include <Rmath.h>
#include <Rinternals.h>
//#include <assert.h>

SEXP
jump( SEXP location, SEXP scale, SEXP cp, SEXP cpV ){
  // location (double vector) are the logistic regression y-values
  // scale (double scalar) is the logistic scale parameter
  // cp (double vector) are the cutpoints
  // cpV (integer vector) are the corresponding 'jumps' for each cutpoint interval
  ////////////////////////////////////////////////////////

  // DECLARATIONS
  int i, j; // Counters
  int ptN = length( location ); //The number of jumpers
  //double Location[ptN], Scale; //Pointers
  double Scale;
  Rboolean rclosed = TRUE, allins = FALSE; // assumed values for interval calculation
  int mfl = 0, lastleft = 0, nCp;
  SEXP res; // the output: will be length of cpV, and have sum length of location

  nCp = length( cp ); // the number of cutpoints
  double ptCp[nCp]; // pointer to the cutpoints
  for( i = 0; i < nCp; i++ ) ptCp[i] = REAL( cp )[i];

  int ptCpV[nCp+1]; //pointer to the cutpoint definitions
  for( i = 0; i < ( nCp + 1 ); i++ ) ptCpV[i] = INTEGER( cpV )[i];

  //for( i = 0; i < ( nCp - 1 ); i++ ) printf( "Cut points values are: %i", ptCpV[i] );
  //printf( "Length of cut points is: %i", nCp );

  Scale = REAL( scale )[0]; // pointer to the scale parameter

  double rlg; // the random logistic draw value
  int cpI; // the cutpoint index
  int jumpV[ptN]; // the vector to store jumps
  double u;

  // THE WORK
  PROTECT( res = allocVector( INTSXP, nCp + 1 ) );//keeps "res" from being garbage-collected by R
                                                  //b/c res is not an R object

  GetRNGstate();
  for( i = 0; i < ptN; i++ ){
    //Location[i] = REAL( location )[i];
    u = unif_rand();
    rlg = REAL( location )[i] + Scale * log(u / (1. - u));
    //rlg = rlogis( Location[i], Scale ); //Make the random draw from the logistic distribution
    cpI = findInterval( ptCp, nCp, rlg, rclosed, allins, lastleft, &mfl ); //Find the interval in cp
    //printf( "%i, ", cpI );
    jumpV[i] = ptCpV[cpI]; //Get the actual jump
  }

//Get the corresponding numbers moving
  for( i = 0; i < (nCp + 1); i++ ){
    INTEGER( res )[i] = 0; //res starts from zero
    for( j = 0; j < ptN; j++ ) if( ptCpV[i] == jumpV[j] ) INTEGER(res)[i]++; //increment res if a jumper lands there
  }

  PutRNGstate();
  UNPROTECT(1);
return res;
}


SEXP
placeJ( SEXP jumps, SEXP jumpV, SEXP nodes, SEXP cNode, SEXP allNodes ){
  // jumps (integer vector) is the numbers jumping
  // jumpV (integer vector) is the distances jumped
  // nodes (integer vector) is the series of nodes (increasing, but can have "holes")
  // cNode (integer scalar) is the current (i.e. jumping from) node
  // allNodes (integer vector) is the series of all of the Nodes
  ///////////////////////////////////////////////////////////
// This function takes a jump() result and puts fish in the appropriate reach

  int i;
  int nNodes = length( nodes ), nAllNodes = length( allNodes ), nJumps = length( jumps ), nJumpV = length( jumpV );
  int ptJumps[nJumps], ptJumpV[nJumpV], ptNodes[nNodes], ptCNode = INTEGER( cNode )[0], ptAllNodes[nAllNodes];
  for( i = 0; i < nJumps; i++ ) ptJumps[i] = INTEGER( jumps )[i];
  for( i = 0; i < nJumpV; i++ ) ptJumpV[i] = INTEGER( jumpV )[i];
  for( i = 0; i < nNodes; i++ ) ptNodes[i] = INTEGER( nodes )[i];
  for( i = 0; i < nAllNodes; i++ ) ptAllNodes[i] = INTEGER( allNodes )[i];

  int nums[nNodes]; // Used to temporarily store results
  SEXP res;
  PROTECT( res = allocVector( INTSXP, nAllNodes ) );

  // Fill the results vector with zeroes
  for( i = 0 ; i < nNodes ; i++ ) nums[i] = 0;
  for( i = 0 ; i < nAllNodes ; i++ ) INTEGER( res )[i] = 0;

  // Go through the jumps and put them in the correct spot on the path
  // The imax2, imin2 bit ensures that there is no leakage over the endpoints
  int thisNode = 0;
  for( i = 0; ptNodes[ thisNode ] != ptCNode; i++ ) thisNode = i;
  for( i = 0; i < nJumpV; i++ ) nums[ imin2( imax2( ( ptJumpV[i] + thisNode ), 0 ), nNodes - 1 ) ] += ptJumps[i];

  // Using the nums vector, fill the res vector
  for( i = 0; i < nNodes; i++ ) INTEGER( res )[ ptNodes[i] - 1 ] = nums[ i ];

  UNPROTECT( 1 );
return( res );
}


SEXP
doJump( SEXP reaches, SEXP cReach, SEXP allReaches, SEXP location, SEXP scale, SEXP cp, SEXP cpV ){
  // reaches (list of integer vectors) are the location codes in the path
  // allReaches (integer vector) is the series of all of the Reaches
  // location (list of double vectors) is the logistic regression y-value
  // scale (double scalar) is the logistic scale parameter
  // cp (double vector) are the cutpoints
  // cpV (integer vector) are the corresponding 'jumps' for each cutpoint interval
  //////////////////////////////////////////////////////////////////////////

  int l = length( reaches );
  if( l != length( location ) ) perror( "The number of reverse nodes is not equal to the number of migrating groups!" );

  int n = length( allReaches );
  int m = length( cpV );
  int i, j;

  SEXP Nall, res, jumps;
  PROTECT( res = allocVector( INTSXP, n ) );
  PROTECT( Nall = allocVector( INTSXP, n ) );
  PROTECT( jumps = allocVector( INTSXP, m ) );

  for( i = 0; i < n; i++ ) INTEGER( res )[i] = 0;

  for( i = 0; i < l; i++ ){
    // Get the jumps
    jumps = jump( VECTOR_ELT( location, i ), scale, cp, cpV );
    // Place the jumpers
    Nall = placeJ( jumps, cpV, VECTOR_ELT( reaches, i ), cReach, allReaches );
    // Add to the result object
    for( j = 0; j < n; j++ ) INTEGER( res )[j] += INTEGER( Nall )[j];
  }
  UNPROTECT(3);
return( res );
}
