# The function that builds temperature/flow/environmental data object
.envBuild <- function( dirt, defs, varnames = c("temp", "flow"), nT = 360, year = 2002, baseyear = 1994 ){
  # dirt is a vector of the directories with the data files
  # defs is a vector of the files with the reaches and the associated stations
  # varnames is a vector of the names of the environmental variables
  # nT is the number of 12 hr timesteps (data files are assumed to have daily timestep)
  # year is the year for which environmental data is needed
  # baseyear is the year in the first column of the environmental data (ASSUMPTION: NO MISSING YEARS)
  #       NOTE: The season begins on June 1
  #############################################################
  
  nVars <- ( ( length( dirt ) + length( defs ) + length( varnames ) ) %% 3 == 0 ) * length( dirt )
  if( nVars == 0 ) stop( "The lengths of dirt, defs, and varnames do not match!" )
  
  for( j in 1:nVars ){
    # Get the reaches and the station names
    thedefs <- read.csv( defs[j], comment.char = "#", colClasses = "character" )
    reachlist <- list()
    for( i in 1:nrow( thedefs ) ) reachlist[[i]] <- eval( parse( text = thedefs[i,2] ) )
    allReaches <- sort( unique( unlist( reachlist ) ) )
    allStations <- unique( thedefs[,1] )
    
    reach.df <- matrix( NA, nrow = 0, ncol = 2 )
    for( i in 1:length( reachlist ) ) reach.df <- rbind( reach.df, cbind( thedefs[i,1], reachlist[[i]] ) )
    reach.df <- data.frame( Station = reach.df[,1], Reach = as.integer( reach.df[,2] ), stringsAsFactors = FALSE )
      
    # Get the data from the data directory and store it in a big list
    dat <- list()
    for( i in 1:length( allStations ) ){
      dat[[i]] <- read.table( paste( dirt[j], dir( dirt[j], pattern = allStations[i] ), sep = "/" ), header = TRUE )[1:(nT/2),]
      if( names( dat[[i]] )[1] == "Date" ) dat[[i]] <- dat[[i]][2:ncol(dat[[i]])]
    }
    names( dat ) <- allStations
    
    # Build a data.frame with time and reaches
    # T is the 12-hour timestep, starting on June 1
    if( !exists( "outp" ) ) outp <- expand.grid( T = 1:nT, reach = allReaches )

    # Fill the data.frame with the appropriate temperature data
    # The temperature data is daily, whereas the model timestep is 12-hour
    for( reach in 1:length( allReaches ) ) outp[ ( 1 + ( reach - 1 )*nT ):( reach*nT ), 2+j ] <- rep( dat[[ which( allStations == reach.df[ reach.df$Reach == reach, 1 ] ) ]][,year - baseyear + 1], each = 2 )
    names( outp )[ ncol(outp) ] <- varnames[j]
  }

outp  
}

.movedfTrim <- function( CU, move.df ){
#  This function trims the envData according to the CU object to reduce the data space
#  CU is the CU object
#  move.df is the full movement df for the logit movement model
###########################################################
require(gdata)
  nCU <- length( CU )
  # nReaches <- max( as.numeric( levels( move.df$reach ) ) )
  nT <- max( as.numeric( levels( move.df$T ) ) )
     
  for( cu in 1:nCU ){
    cat( "Trimming reaches for CU ", cu, "... ", sep = "" )
    # Get the subset of move.df that corresponds to this CU
    move.df.sub <- move.df[ move.df$CU == cu, ]
    # Extract the timesteps and reaches that are appropriate to this CU
    nReachCU <- length( CU[[cu]]$allReaches )
    nTCU <- length( CU[[cu]]$T )
    
    move.df.sub <- move.df.sub[ rep.int( CU[[cu]]$T, nReachCU ) + rep( nT*( CU[[cu]]$allReaches - 1 ), each = nTCU ) , ]
    
    if( exists( "outp" ) ) outp <- rbind( outp, move.df.sub )
    if( !exists( "outp" ) ) outp <- move.df.sub
    
    cat( "Done. \n" )
  }

  outp <- drop.levels( outp )
  
outp
}


.stockParsCreate1 <- function( dirt = NULL, moverates = "move/moveRates02.txt"
                , N = "CU/RunSize.csv", CUdefs = "CU/CUdefns.csv", mvDefs = "move/moveDefns.csv"
                , retdist = NULL, adj = list( c(0,0) )
			    , year.N = 2002, reaches, reachid, nT = 360, nStates = 1, keepStates = 0, minBots = 10
			    , nBots = 1000, cumulPars = NULL
			    , enterProps = list( c( 0.3, 0.7 ) ), sc = 0.5, pNoBOTS = 0, speedRatio = 20
		      , reachNodes = NULL ){
# dirt is deprecated - pass relative paths in their entirety
# moverates is the file with the movement rates, times, distances
# N is file with numbers returning
# CUdefs is a file with the CU definitions
# year is the year to match in the N file  
# reaches is the reaches object (a list with node-to-node reach vectors)
# reachid is a vector with all of the reaches
# nT is the number of timesteps (recycled)
# nStates is a vector of the number of cumulative states by CU
#   CURRENTLY, ONLY ONE (1) STATE IS SUPPORTED
# minBots is a vector of the minimum number of BOTS that a CU can have (recycled)
# cumulPars is a vector of lists with the parameters for cumulative states (recycled)
# enterProps is a list of vectors with the proportions entering each path by CU (recycled)
# sc is a vector of scale parameters for the (movement) jumping distribution (recycled)
# pNoBOTS is a vector of probabilities of death for fish in reaches without BOTS (recycled)
# retdist is the file with the distribution and location for timing.
# adj is a vector list with adjustments to be made to the travel time when
#     building the entry timing distributions, for example to account for bottlenecks
#     when the entry timing is being estimated from the movement rates.  Positive
#     values are for increasing the travel time (making the entry times earlier)
#       NOTE: The season begins on June 1
#############################################################

  # Read in the numbers data
  N <- read.csv( N, header = TRUE )
  N <- na.omit( N )
  # Read in the moverates data
  mvR <- read.table( moverates, header = TRUE )
  # Read in the timing data
  # arrival timing file structure:
  # CU loc T.1 T.2 T.3 ... T.N
  tdat <- read.csv( retdist, header = TRUE )
  timingCUs <- unique(tdat$CU)
  
  # Read in the CU definitions
  CUdefs <- read.csv( CUdefs, header = TRUE, stringsAsFactors = FALSE, comment.char = "#" )
  
  # Pare the CU names from the movement rate data
  CUs <- sort( levels( mvR$CU )[ levels( mvR$CU ) %in% levels( N$CU ) & levels( mvR$CU ) %in% levels( timingCUs ) ] )
  CUs <- CUs[ CUs %in% CUdefs$CU ] 
    
  # Build the cuN object
  cuN <- vector( length = length( CUs ), mode = "list" )
  names( cuN ) <- CUs
  for( i in 1:length( cuN ) ) cuN[[i]] <- N[ N$CU == CUs[i], grep(year.N,names(N))]

  # Recycle the adj list
  adj <- rep( adj, length( CUs ) )
  
  # Build the movement rates object by CU and section
  mvdefs <- read.csv( mvDefs, header = TRUE
      , stringsAsFactors = FALSE, strip.white = TRUE )
  mvreaches <- list()
  for( i in 1:nrow( mvdefs ) ) mvreaches[[i]] <- eval( parse( text = mvdefs$reaches[i] ) )
  if( !all( sort( unique( unlist( mvreaches ) ) ) == sort( unique( unlist( reaches ) ) ) ) ){
    print( "The movement reaches don't cover all reaches - check your definitions." )
    browser()
  }

  for( i in 1:nrow( mvR ) ){
    # Go row by row in the mvR object, get the reaches using the start and end stations
    rs <- mvreaches[[ which( mvdefs$startStation == as.character( mvR$startStation[i] ) 
                & mvdefs$Station == as.character( mvR$Station[i] ) ) ]]
    # Expand over reaches
    thismv <- data.frame( CU = rep.int( mvR$CU[i], length(rs) ), reach = rs
        , y = rep.int( mvR$rate[i], length(rs) ) ) 
    if( exists( "moveRates" ) ){ moveRates <- rbind( moveRates, thismv ) }
    else{ moveRates <- thismv }
  }

  # Get all the CU paths
  reachP <- list()
  for( i in 1:length( CUs ) ) reachP[[i]] <- .reachPath( CUdefs$Name[ CUdefs$CU == CUs[i] ], reaches )
  nP <- max( sapply( reachP, length ) )

  # Split the timing
    arrMats <- list() 
    for( p in 1:nP ) arrMats[[p]] <- as.matrix( tdat[ match( CUs, timingCUs ), -(1:2)] )
  
	# Back-calculate arrival timing from available timing at arrLoc (rough estimate)
	# Calculate total time from release to arrival locations from the mvR object
    arrLoc <- tdat$loc[ match( CUs, timingCUs ) ]
  # Look for CUs that have timing data at the spawning grounds
    atsp <- which( arrLoc == "endpoint" )
    arrI <- integer(0)
    for( a in atsp ) arrI[a] <- max( unlist( reachP[[a]] ) )  # This seems to be 1 less than the reachNodes value? 
  # The nodes at which we have the arrival info
    arrI[ arrLoc != "endpoint" ] <- reachNodes[ match( arrLoc, reachNodes[,1] ), 2 ]
  
  for( i in 1:length( CUs ) ){

		# Get the movement rates for this CU and the paths
	    theRates <- list()
		for( j in 1:length( arrMats ) ) theRates[[j]] <- moveRates$y[moveRates$CU==CUs[i] & moveRates$reach%in%reachP[[i]][[j]] ]
		# Get the path lengths from start of map to timing location
    # A function to extract the length from the start to arrI
    weq <- function(x,y){
      w <- which(x==y)
      if( length(w) == 0 ) stop(paste("Timing location is not on the path for CU ",i,"!",sep=""))
    w
    }
		if( class( reachP[[i]] ) == "list" ){
			nReaches <- sapply( reachP[[i]], FUN = weq, y = arrI[i] )
      meanRate <- numeric(length(nReaches))
      for( k in 1:length(meanRate) ) meanRate[k] <- mean(theRates[[k]][1:nReaches[k]])
		}else{
			nReaches <- weq( reachP[[i]], arrI[i] )
      meanRate <- mean(theRates[[i]][1:nReaches])
		}  
    # Get the average number of timesteps to get to the spawning grounds  
	    T <- nReaches*speedRatio/meanRate
    # A function to shift the timing distributions to the left
      sh <- function( v, s ){
        ss <- sum( v[1:s] )
        v.o <- c(v[-(1:s)],rep(0,s))
        v.o[1] <- v.o[1] + ss
      v.o  
      }
	    # Now subtract the T from the spawn times
      for( k in 1:nP ) arrMats[[k]][i,] <- sh( arrMats[[k]][i,], round( T[k] + adj[[i]][k] ) )
	}
  # Move the arrT object down one level in the arrT object
  arrT <- list( arrMats = arrMats, mr = NA )
  # The approximate initial movement rates
  for( i in 1:length(CUs) ){
	  arrT$mr[i] <- mvR$rate[ as.character(mvR$CU) == CUs[i] & mvR$startStation == "Release" ]/speedRatio
  }

  # Build the CU object
  CU <- vector( length = length( CUs ), mode = "list" )
  minBots <- rep( minBots, length.out = length( CUs ) )
  nBots <- rep( nBots, length.out = length( CUs ) )
  cumulPars <- rep( cumulPars, length.out = length(CUs) )
  enterProps <- rep( enterProps, length.out = length(CUs) )
  nT <- rep( nT, length.out = length( CUs ) )
  sc <- rep( sc, length.out = length( CUs ) )
  pNoBOTS <- rep( pNoBOTS, length.out = length( CUs ) )
  
  botsColNames <- character( 2 + nStates + nStates*keepStates )
  botsColNames[1:2] <- c("reach", "path")
  botsColNames[ seq(3, by=keepStates+1, length.out = nStates) ] <- paste( "state" , 1:nStates , sep="" )
  for( i in 1:nStates ) botsColNames[ (1:keepStates)+3+(i-1)*(keepStates+1) ] <- paste( "keep", i, 1:keepStates, sep = ".") 
  for( i in 1:length( CUs ) ){
    CU[[i]] <- list( reach = reachP[[i]],
      T = 1:nT[i], 
      N = matrix( 0, ncol = length( reachP[[i]] ), nrow = length( reachid ) ),
      bots = matrix( NA, nrow = nBots[i], ncol = length( botsColNames )
           , dimnames = list( NULL, botsColNames ) ),
      tags = matrix( NA, nrow = 0, ncol = length( botsColNames )
		   , dimnames = list( NULL, botsColNames ) ),
      minBots = minBots[i],
      deadBots = 0,
      spawners = 0,
      cumulPars = cumulPars[[i]],
      enterProps = enterProps[[i]] / sum( enterProps[[i]] ),
      sc = sc[i],
      CU = i,
      CUname = CUs[i] ,
      CUcommon = CUdefs$Name[CUdefs$CU == CUs[i]],
      pNoBOTS = pNoBOTS[i]
    )
  }
  # Finish up with the CU object
  for( m in 1:length(CU) ) CU[[m]]$allReaches <- sort( unique( unlist( CU[[m]]$reach ) ) )                       
 
  
return( list( CU = CU, cuN = cuN, moveRates = moveRates, arrT = arrT ) )  
}


# Define a function which will take the end node and return the vector of reaches required to get there
.reachPath <- function( r, rchs ){
  reachNames <- names( rchs )
  # Get the name of the current node
    splitNames <- strsplit( reachNames, " : " )
    endNames <- sapply( splitNames, function( x ) x[2] )
    currName <- reachNames[ r == endNames ]
    if( length( currName ) == 0 ) stop( paste( "'", r, "' is not a location in the database..." ) )
  # Save the current name
  outNames <- vector( length = length( currName ), mode = "list" )
  for( i in 1:length( outNames ) ) outNames[[i]] <- c( outNames[[i]], currName[i] )
  
  newSecs <- 1
  while( newSecs > 0 ){
    newSecs <- 0	# Keep track of new sections added, reset to zero
    for( path in 1:length(outNames) ){ #Loop over the number of paths so far...
      # Extract the downstream node name
        nodeName <- strsplit( currName[path], " : " )[[1]][1]
      # Get the next section of reaches
        currName <- na.omit( reachNames[ nodeName == endNames ] )
      # Save the current name(s):
      # If there are multiple new paths, add these paths now...
        if( length( currName ) > 1 ){ 
	  for( i in 2:length(currName) ){
	    # Add the newly discovered paths to the outNames list, and save the current Name
            j <- length( outNames ) + i - 1
	    outNames[[j]] <- c( outNames[[path]], currName[i] )
	  }
	}
      # Save the current name to the original path
        if( length( currName ) > 0 ){
	  outNames[[path]] <- c( outNames[[path]], currName[1] )
	  newSecs <- newSecs + 1
	}
    }
  }# end while
  reachOut <- list()
  for( i in 1:length(outNames) ) reachOut[[i]] <- sort( unique( unlist( rchs[ reachNames %in% outNames[[i]] ] ) ) )

return( reachOut )
}


.harvBuild <- function( locfile, timefile, reachid, nT ){
  # Read in the location file which contains the locations of all fisheries in terms of reach IDs
    fishDefs <- read.csv( locfile, comment.char = "#", strip.white = TRUE, colClasses = "character" )
    # Reformat locations to a list
    fisheries <- list()
    for( r in 1:nrow( fishDefs ) ) fisheries[[r]] <- eval( parse( text = fishDefs[r,2] ) )
    names( fisheries ) <- fishDefs[,1]

  # Read in the timing file which contains the openings of all fisheries in terms of the timestep
    fishOpens <- read.csv( timefile, comment.char = "#", strip.white = TRUE, colClasses = "character" )
    # Reformat openings and make sure that it matches the structure/order of 'fisheries'
    openings <- list()
    hrates <- list()
    for( r in 1:length( fisheries ) ){
      i <- pmatch( names( fisheries )[r], fishOpens[,1] )
      openings[[r]] <- eval( parse( text = fishOpens[i,2] ) )
	  if( !all( openings[[r]] %in% 1:nT ) ) warning( paste( names(fisheries)[r], " has openings that are outside of the range of timesteps" ) )
      # Also get the harvest rates
      hrates[[r]] <- eval( parse( text = fishOpens[i,3] ) )
	  if( !all( hrates[[r]] <= 1 ) ) stop( paste( names(fisheries)[r], " has at least one harvest rate > 1" ) )
    }
    names( openings ) <- names( fisheries )
    names( hrates ) <- names( fisheries )
    
  # Convert fishery information to harvest matrix
  harvM <- matrix( 0., nrow = length( reachid ), ncol = nT , dimnames = list( paste( "Reach", reachid, sep = "" ), paste( "Time", 1:nT, sep = "" ) ) )  
  for( r in 1:length( fisheries ) ) harvM[ fisheries[[r]], openings[[r]] ] <- hrates[[r]]
  list( harvM = harvM, fisheries = fisheries, openings = openings, hrates = hrates )
}

harvAdjust <- function( h, t, fisheries, adj ){
	# Fisheries is a character vector with the names of the fisheries
	# Adj is a vector (recycled) of adjustments to the harvest rates
	adj <- rep( adj, length.out = length( fisheries ) )
	for( r in 1:length( fisheries ) ){
	  h$harvM[ h$fisheries[[ fisheries[r] ]] ,t ] <- 
			  h$harvM[ h$fisheries[[ fisheries[r] ]] ,t] * adj[r]
  }
h
}



.moveCL <- function( x, y, cpV = -1:8, allReaches, t ){

# x is the CU list with
# N is a matrix of the numbers in each reach ( nrow = number of reaches, ncol = number of paths )
# y is a matrix with the X*b
# cpV is a vector of movements corresponding to the cutpoint intervals (integer increasing)
# sc is the scale parameter for the logistic distribution
# t is the current timestep

   # This model describes the movement of fish in a particular reach
   # It is a multinomial, something like this:
   #
   #   ^
   #   |      ##
   #   |      ##
   # N |      ##
   #   |      ##   ##
   #   |      ##   ##   ##
   #   | ##   ##   ##   ##   ##
   #    ----|----|----|----|---->
   #     -1    0    1    2    3
   #             movement

   # p( m >= 0 ) = inv.logit( Xb )
   # p( m >= 1 ) = inv.logit( Xb - c2 )
   # p( m >= 2 ) = inv.logit( Xb - c3 )
   # p( m >= 3 ) = inv.logit( Xb - c4 )
   
   # where the cutpoint parameters 0 = c1 < c2 < c3 < c4

   # PROCEDURE:
   # 1. Determine the value of the latent variable z, where z_i = X_i * b + e_i
   
   # 2. Then m_i = 
   #               -1    if z_i < 0
   #                0    if 0 < z_i < c2
   #                1    if c2 < z_i < c3
   #                2    if c3 < z_i < c4
   #                3    if z_i > c4

   # Extract the cutpoints matrix from the CU list
    cp <- x$cpAll[ , grep( "cp", names( x$cpAll ) ) ]
      
   # Move fish   
   # Extract the appropriate y
    ytemp <- rep.int( NA, length( allReaches ) )
    ytemp[ x$allReaches ] <- y[ y$CU == x$CU[1], ]$y
    
    for( path in 1:ncol( x$N ) ){
      wfish <- which( x$N[,path] != 0 )
      if( length( wfish ) != 0 ){
        # Movement matrix
        M <- matrix( 0, nrow = length( wfish ), ncol = length( allReaches ) )
        for( i in 1:length( wfish ) ) M[i,] <- .doJump( n = x$N[ wfish[i],path], location = ytemp[ wfish[i] ], scale=x$sc, cp = c( 0, cp[ wfish[i],] ), cpV = cpV, reaches = x$reach[[path]], currReach = allReaches[ wfish[i] ], allReaches = allReaches )        
        x$N[,path] <- colSums( M )
        # Keep track of numbers moving past the counting nodes
        for( node in 1:length( x$cnodes ) ){
	  if( x$cnodes[node] %in% x$allReaches ){
	    x$counts[ t, node ] <- x$counts[ t, node ] + sum( M[ wfish < x$cnodes[ node ], (1:ncol(M)) >= x$cnodes[ node ] ] ) - sum( M[ wfish >= x$cnodes[ node ], (1:ncol(M)) < x$cnodes[ node ] ] )
	  }
	}
      }
    }
   # Move BOTS
    wfish <- which( !is.na( x$bots[,1] ) )
    for( i in wfish ){
      x$bots[i,1] <- .botJump( location = ytemp[ x$bots[i,1] ], scale = x$sc, cp = c( 0, cp[ x$bots[i,1], ] ), cpV = cpV, reaches = x$reach[[ x$bots[i,2] ]], currReach = x$bots[i,1] )
    }
   # Move tags
  if( !is.null( x$tags ) ){
    wfish <- which( x$tags[,1] != 0 )
    if( length( wfish ) > 0 ){
      tagsnext <- x$tags
      for( i in wfish ){
        tagsnext[i,] <- c( .botJump( location = ytemp[ x$tags[i,1] ], scale = x$sc, cp = c( 0, cp[ x$tags[i,1], ] ), cpV = cpV, reaches = x$reach[[ x$tags[i,2] ]], currReach = x$tags[i,1] ), x$tags[i,-1] )
      }
        # Subset the tags to those with fish
        if( length( wfish ) > 1 ){
	  tnext <- tagsnext[wfish,]
	  tcurr <- x$tags[wfish,]
	}else{
	  tnext <- matrix( tagsnext[wfish,], ncol = ncol(tagsnext)
			  , dimnames = list( rownames(tagsnext)[wfish], colnames(tagsnext) ) )
	  tcurr <- matrix( x$tags[wfish,], ncol = ncol(x$tags)
			  , dimnames = list( rownames(x$tags)[wfish], colnames(x$tags) ) )
	}
        # Count tags moving past counting nodes and add to the x$counts object
        # Also, count tags moving past listening stations
        lst <- x$tnodes[ x$tnodes %in% x$allReaches ]
        taghits <- .listentags( tnext, tcurr, reaches = x$reach, stations = c( x$cnodes, lst ) )
	taghits.c <- taghits[1:length(x$cnodes)]
	taghits.t <- taghits[-(1:length(x$cnodes))]
        x$counts[ t, ] <- x$counts[ t, ] + sapply( taghits.c, length )
        # While we're at it, we should keep track of the tag hits
        st <- rep( lst, sapply( taghits.t, length ) )
        id <- unlist( taghits.t )
        if( length( id ) > 0 ) x$taghits <- rbind( x$taghits, data.frame( t=t, station = st, ID = id ) )
        x$tags[wfish,] <- tnext
    }
  }
return( x )
}


# The return function which distributes returns over the first few reaches
.retF <- function( n, reachids, node, allReaches, pars ){
   if( n != 0 ){
     # Random half-normal draw to determine in which reach returns "land"
     M <- round( abs( rnorm( n, 0, pars$mr / sqrt( 2 / pi ) ) ) ) + node # This draw gets you a continuous number
                                   # Note that the pars$mr is the average movement rate = sigma * sqrt( 2 / pi )

     # Discretize...
     breaks <- c( reachids[1], reachids + 1 )
     overpath <- hist( M , breaks, plot = FALSE )$counts
     # Place numbers into output object
     outp <- rep.int( 0, length( allReaches ) )
     outp[reachids] <- overpath
   }else{ outp <- rep.int( 0, length( allReaches ) ) }
return( outp )
}  

  
# The function for offing fishies  
.killFish <- function( N, kill, reachlist, stoch, pNoBOTS = 0 ){
  for( path in 1:ncol( N ) ){
    wfish <- N[,path] != 0
    wBots <- !is.na( kill[,1] )
    wMulti <- kill[,3] != 0 & wBots
        
    if( sum( wfish ) > 0 ){
      deads <- integer( nrow(N) )
      # Some reaches might have NO BOTS, which is a tricky one...  choose the average of the neighbouring reaches with bots
      if( sum( wfish & !wBots ) > 0 ){
        probs <- 0.
        # Get 4 neighbours
        fishNoBots <- which( wfish & !wBots )
        for( i in 1:length( fishNoBots ) ){
          currReach <- which( reachlist[[path]] == fishNoBots[i] )
          reachRange <- reachlist[[path]][ max( 1, currReach - 2 ):min( length( reachlist[[path]] ), currReach + 2 ) ]
          probs[i] <- mean( kill[ reachRange, 1 ] , na.rm = TRUE )
        }
        # Kill some fish
        probs[ is.na( probs ) ] <- pNoBOTS    # If there aren't any BOTS nearby
        if( stoch ){ deads[ fishNoBots ] <- rbinom( n = length( fishNoBots ), size = N[ fishNoBots, path ], prob = probs ) }
        else{ deads[ fishNoBots ] <- round( N[ fishNoBots, path ] * probs ) }
      }
      # Some reaches might only have one BOTS, which screws beta-binomial up.  In that case, just use the binomial
      oneBots <- wfish & wBots & !wMulti
      moreBots <- wfish & wMulti
      
      # Generate deaths
      if( stoch ){
        if( sum( oneBots ) > 0 ) deads[ oneBots ] <- rbinom( n = sum( oneBots ), size = N[ oneBots, path ], prob = kill[ oneBots, 1 ] )
        if( sum( moreBots ) > 0 ) deads[ moreBots ] <- rbetabinom.ab( n = sum( moreBots ), size = N[ moreBots, path ], shape1 = kill[ moreBots, 2 ], shape2 = kill[ moreBots, 3 ] )
      }
      if( !stoch ){
        if( sum( oneBots ) > 0 ) deads[ oneBots ] <- round( N[ oneBots, path ] * kill[ oneBots, 1 ] )
        if( sum( moreBots ) > 0 ) deads[ moreBots ] <- round( N[ moreBots, path ] * kill[ moreBots, 2 ] / ( kill[ moreBots, 2 ] + kill[ moreBots, 3 ] ) )
      }
      # Subtract the deads
      deads[ is.na( deads ) ] <- 0
      N[, path ] <- N[, path ] - deads
    }
  }  
N
}

# The older version of killFish - doesn't use bots (cumulative effects)
.killFish2 <- function( N, kill, stoch ){
  for( path in 1:ncol( N ) ){
    wfish <- which( N[,path] != 0 & kill != 0 )
    if( length( wfish ) != 0 ){
      if( stoch ) N[ wfish, path ] <- pmax( N[ wfish, path ] - rbinom( n = length( wfish ), size = N[ wfish, path ], prob = kill[ wfish ] ), 0 )
      if( !stoch ) N[ wfish, path ] <- pmax( round( N[ wfish, path ] - N[ wfish, path ] * kill[ wfish ] ), 0 )
    }
  }
N
}

# The function for offing BOTS
.killBOTS <- function( bots, pars ){
# pars elements:
# $type: vector of mortality types. "norm" and "norm.avg" are the allowed types currently
# $whichState: vector of states that are causing each $type of mortality.  Same length as $type.
# $whichKeep: list of vectors. This is for recent history-type states that are going to
#             use the "norm.avg" type. Each vector has entries corresponding to the desired
#             history states. The names of the states used are built as "keep.whichState.whichKeep"
#             to match the names of the states in the bots object.
# $par1 and $par2: parameters of the function relating probability of death to the states.
#                  Currently, these are the mean and sd of a cumulative Normal distribution
#                  for both "norm" and "norm.avg" types.
# $pfunc: function that combines the different probabilities of death into a total 
#         probability of death.  First argument must be a matrix of probabilities 
#         of death with individual bots as rows and probabilities of death for 
#         each mortality type as columns.  Function should return a vector with
#         the mean and variance of the probability of death as the first two elements and
#         the relative probabilities of death for each mortality type (sum to 1) as the 
#         following elements.
# $pfpars: vector of additional arguments passed to $pfunc
# $rate: optional known probability of death (for pars$type = "knownRate")

  hasBot <- which( !is.na( bots[,1] ) )
  nKill <- 0
  killLoc <- integer(length=0)
  if( length( hasBot ) > 0 ){
	pdie <- matrix( 0., ncol = length( pars$type ), nrow = length( hasBot ) )
	for( ty in 1:length( pars$type ) ){
	  pdie[,ty] <- switch( pars$type[ty]
				  , norm = pnorm( bots[ hasBot, paste( "state", pars$whichState[ty], sep = "" ) ], pars$par1[ty], pars$par2[ty] )
				  , norm.avg = pnorm( rowMeans( bots[ hasBot, paste( "keep", pars$whichState[ty], pars$whichKeep[[ty]], sep = "." ), drop = FALSE ] ), pars$par1[ty], pars$par2[ty] )
                  , knownRate = pars$rate[ bots[hasBot,1] ] 
		  )
	  if( is.null( pdie[,ty] ) ) stop( paste( "Error calculating exposure effects: ", pars$type[ty], " is not a known pars$type" ) )
	}
	  
	# Combine probability of death for each BOTS
	if( ncol(pdie) > 1 ) pdie.out <- apply( pdie, 1, FUN = pars$pfunc, pars$pfpars )[,1]
	else pdie.out <- pdie

    draws <- runif( length( hasBot ), 0, 1 )
    # "Kill" BOTS by giving them NA values
    # for( i in 1:length( hasBot ) ) if( draws[i] < pdie[i] & any( bots[ hasBot[ ( 1:length(hasBot) ) != i ], 1 ] == bots[ hasBot[i], 1 ] ) & any( !is.na( bots[ bots[ , 1 ] == bots[ hasBot[i], 1 ], 3] ) ) ) bots[ hasBot[i], 3:ncol( bots ) ] <- NA
    for( i in 1:length( hasBot ) ){
	  death <- isTRUE( draws[i] < pdie.out[i] )
      if( death ){
		killLoc <- c(killLoc, bots[hasBot[i],1])
        bots[ hasBot[i], ] <- NA
        nKill <- nKill + 1 
      }
    }
  }
list( bots = bots, nKill = nKill, killLoc = killLoc )
}


# The function for offing tags
.killTags <- function( tags, pars )	.killBOTS( bots = tags, pars = pars )


# This function places new bots using a vector of newBots
.putBots <- function( bots, newBots, path ){
  # A small number to initialize cumulative effects with
    small <- 1e-6
  # Bots that have yet to be defined
    botEmpties <- which( is.na( bots[,1] ) )
  # Generate vector of reaches for individual bots
    indReach <- integer(0)
    haveInds <- which( newBots != 0 )
    for( i in haveInds ) indReach <- c( indReach, rep.int( i, newBots[i] ) )
  # Place the bots
    if( length( indReach ) <= length( botEmpties ) ) bots[ botEmpties[ 1:length(indReach) ], ] <- cbind( indReach, path, matrix( small, nrow = length(indReach), ncol = ncol(bots)-2 ) )
    if( length( indReach ) > length( botEmpties ) ) stop( "Something's gone wrong: There's not enough room for the BOTS!!!" )
bots
}        


# This function calculates mortality rate parameters from bot attributes
.mortCalc <- function( bots, pars, allReaches ){
  # pars elements:
  # $type: vector of mortality types. "norm" and "norm.avg" are the allowed types currently
  # $whichState: vector of states that are causing each $type of mortality.  Same length as $type.
  # $whichKeep: list of vectors. This is for recent history-type states that are going to
  #             use the "norm.avg" type. Each vector has entries corresponding to the desired
  #             history states. The names of the states used are built as "keep.whichState.whichKeep"
  #             to match the names of the states in the bots object.
  # $par1 and $par2: parameters of the function relating probability of death to the states.
  #                  Currently, these are the mean and sd of a cumulative Normal distribution
  #                  for both "norm" and "norm.avg" types.
  # $pfunc: function that combines the different probabilities of death into a total 
  #         probability of death.  First argument must be a matrix of probabilities 
  #         of death with individual bots as rows and probabilities of death for 
  #         each mortality type as columns.  Function should return a vector with
  #         the mean and variance of the probability of death as the first two elements and
  #         the relative probabilities of death for each mortality type (sum to 1) as the 
  #         following elements.
  # $pfpars: vector of additional arguments passed to $pfunc
	
  hasBot <- which( !is.na( bots[,1] ) )
  outp <- list( bbpars = matrix( NA, nrow = length( allReaches ), ncol = 3 )
		  , props = matrix( NA, nrow = length( allReaches ), ncol = length( pars$type ) ) )
  
  if( length( hasBot ) > 0 ){
	  pdie <- matrix( 0., ncol = length( pars$type ), nrow = length( hasBot ) )
	  for( ty in 1:length( pars$type ) ){
        pdie[,ty] <- switch( pars$type[ty]
		              , norm = pnorm( bots[ hasBot, paste( "state", pars$whichState[ty], sep = "" ) ], pars$par1[ty], pars$par2[ty] )
			          , norm.avg = pnorm( rowMeans( bots[ hasBot, paste( "keep", pars$whichState[ty], pars$whichKeep[[ty]], sep = "." ), drop = FALSE ] ), pars$par1[ty], pars$par2[ty] )
			  )
		if( is.null( pdie[,ty] ) ) stop( paste( "Error calculating exposure effects: ", pars$type[ty], " is not a known pars$type" ) )
	  }

	# Combine probability of death for each BOTS
	  
	  pdie.out <- split.data.frame( pdie, bots[hasBot,1] )
	  pdie.out <- sapply( pdie.out, FUN = pars$pfunc, pars$pfpars )
	  
	# Get MOM estimates for beta distribution parameters by reach	  
      reaches <- as.numeric( colnames( pdie.out ) )	  
	  mu <- pdie.out[1,]
	  v <- pdie.out[2,]
      fac <- mu*( 1 - mu )/v - 1
      fac[ !is.finite( fac ) ] <- NA
	  
      outp$bbpars[ reaches, ] <- cbind( mu, pmax( 0, mu * fac, na.rm = TRUE ), pmax( 0, ( 1 - mu ) * fac, na.rm = TRUE ) )
	  outp$props[ reaches, ] <- t( pdie.out[-(1:2),] )
  }
outp
}

pfunc.cTwT <- function( x, c = 0.5 ){
	if( !is.numeric(c) ) stop( "Overlap parameter must be numeric" )
	if( length(c) > 1 ) warning( paste( "Overlap parameter has length ", length(c), "... using first element only." ) )
	c <- c[1]
	if( is.vector(x) ) x <- t(x)
	del <- abs(x[,1] - x[,2])
	s <- x[,1] + x[,2]
	p <- s*(2-c)/2 + del*c/2
	props <- (x[,1:2] - (s-del)*c/4)/p
	if( !is.vector(props) ) props <- colMeans( props )
	c( mean(p, na.rm = TRUE), var(p, na.rm = TRUE), props )
}


# This function spawns new bots
.budBOTS <- function( bots, pars = list( type = 3, minBots = NULL, growFrac = NULL ) ){
  hasBot <- which( !is.na( bots[,1] ) )
  if( length( hasBot ) > 0 ){
    nStates <- ncol( bots ) - 2
    if( pars$type == 1 ){ #Only replace dead BOTS
      deadBot <- which( is.na( bots[hasBot,3] ) ) 
      for( state in 1:nStates ){
        reaches <- unique( bots[ deadBot, 1 ] )
        for( reach in reaches ){
          botNew <- bots[ deadBot, 1 ] == reach
          botReplace <- quantile( bots[ bots[ hasBot, 1 ] == reach, state + 2 ], probs = runif( sum( botNew ) ), na.rm = TRUE )
          if( is.na( botReplace ) ) browser()
          bots[ deadBot[ botNew ], state + 2 ] <- botReplace
        }
      }
    } #endif type == 1
    if( pars$type == 2 ){ #Fill reaches so that they have at least minBots BOTS
      occReach <- rle( sort.int( bots[hasBot,1], method = "quick") )
      toFill <- which( occReach$lengths < pars$minBots )
      empties <- which( is.na( bots[,1] ) ); emptycounter <- 1
      for( reach in toFill ){
        for( state in 1:nStates ){
          botReplace <- quantile( bots[ bots[ hasBot, 1 ] == occReach$values[reach], state + 2 ], probs = runif( pars$minBots - occReach$lengths[reach] ), na.rm = TRUE )
          if( is.na( botReplace ) ) browser()
          bots[ empties[ emptycounter:( emptycounter + length( botReplace ) - 1 ) ], state + 2 ] <- botReplace
        }
        emptycounter <- emptycounter + length( botReplace )
      }      
    } #endif type == 2
    if( pars$type == 3 ){ #Bump up all reaches to keep the number of BOTS up
      empties <- which( is.na( bots[,1] ) ); emptycounter <- 1
      Nempty <- length( empties ); growFrac <- min( Nempty / ( nrow( bots ) + 1 ), pars$growFrac )
      hasBots <- unique( bots[hasBot,1] )
      if( length( hasBots ) != 0 ){
        for( reach in hasBots ){
          botInd <- which( bots[,1] == reach )
          for( path in unique( bots[ botInd, 2 ] ) ){
            nNew <- ceiling( growFrac * sum( bots[ botInd, 2 ] == path ) ) # Use ceiling to make sure that lonely BOTS get bumped
            if( nNew > 2 ) nNew <- nNew - 1                                # Bump down the reaches with more BOTS to not run out of room
            for( state in 1:nStates ){
              botNew <- quantile( bots[ botInd, state + 2 ], probs = runif( nNew ), na.rm = TRUE )
              if( any( is.na( botNew ) ) ) browser()
              bots[ empties[ emptycounter:( emptycounter + length( botNew ) - 1 ) ], state + 2 ] <- botNew
            }
          emptycounter <- emptycounter + length( botNew )
          } 
        }
      }
      cat( emptycounter, "BOTS have been bud from existing BOTS.", Nempty - emptycounter, "empty slots for BOTS remain. \n" )
    } #endif type == 3
  }
bots  
}        

# This function updates BOTS attributes
.botUpdate <- function( bots, deltaAtt, keepRecent = 8, currentVals = NA ){
  # deltaAtt is a matrix with rows corresponding to the reaches in reachid and columns corresponding to BOTS states
  # keepRecent says how many recent data values to keep track of
  # currentVals is a matrix with rows corresponding to the reaches in reachid and columns corresponding to BOTS states
  if( any( !is.na( bots[,1] ) ) ){
    deltaAtt[ is.na( deltaAtt ) ] <- 0.
	currentVals[ is.na( currentVals ) ] <- 0.
    if( is.vector( deltaAtt ) ) bots[, 3 ] <- bots[, 3 ] + deltaAtt[ bots[,1] ]
    if( !is.vector( deltaAtt ) ){
		bots[, seq(3, by = keepRecent+1, length.out = ncol(deltaAtt) ) ] <- 
				bots[, seq(3, by = keepRecent+1, length.out = ncol(deltaAtt) ) ] + as.matrix( deltaAtt[ bots[,1], ] )
	}
	if( is.vector( currentVals ) ){
	  # Move the currentVals along
	  bots[, 5:(5+keepRecent-2)] <- bots[, 4:(4+keepRecent-2)]
	  # Put in the current value
	  bots[, 4 ] <- currentVals[ bots[,1] ]
	} 
	if( !is.vector( currentVals ) ){
	  # Move the currentVals along
	  ix <- as.vector( apply( matrix(1:ncol(currentVals)), 1
	                 , function(x) (5:(5+keepRecent-2))+(keepRecent+1)*(x-1) ) )
	  bots[, ix] <- bots[, ix - 1]
	  # Put in the current value
	  bots[, seq( 4, by = keepRecent+1, length.out = ncol(currentVals) ) ] <- as.matrix( currentVals[ bots[,1], ] )	
	}
  }
bots  
}        

# This function updates tags attributes
.tagsUpdate <- function( tags, deltaAtt, keepRecent = 8, currentVals = NA ){
	# deltaAtt is a matrix with rows corresponding to the reaches in reachid and columns corresponding to BOTS states
	nospawn <- !( tags[,1] == 0 | is.na(tags[,1]) ) 
	if( any( nospawn ) ){
		deltaAtt[ is.na( deltaAtt ) ] <- 0.
		currentVals[ is.na( currentVals ) ] <- 0.
		if( is.vector( deltaAtt ) ) tags[ nospawn, 3 ] <- tags[ nospawn, 3 ] + deltaAtt[ tags[nospawn,1] ]
		if( !is.vector( deltaAtt ) ){
			tags[ nospawn, seq(3, by = keepRecent+1, length.out = ncol(deltaAtt) ) ] <- 
			tags[ nospawn, seq(3, by = keepRecent+1, length.out = ncol(deltaAtt) ) ] + as.matrix( deltaAtt[ tags[nospawn,1], ] )
		}
		if( is.vector( currentVals ) ){
			# Move the currentVals along
			tags[ nospawn, 5:(5+keepRecent-2)] <- tags[ nospawn, 4:(4+keepRecent-2)]
			# Put in the current value
			tags[ nospawn, 4 ] <- currentVals[ tags[nospawn,1] ]
		} 
		if( !is.vector( currentVals ) ){
			# Move the currentVals along
			ix <- as.vector( apply( matrix(1:ncol(currentVals)), 1
							, function(x) (5:(5+keepRecent-2))+(keepRecent+1)*(x-1) ) )
			tags[ nospawn, ix] <- tags[ nospawn, ix - 1]
			# Put in the current value
			tags[ nospawn, seq( 4, by = keepRecent+1, length.out = ncol(currentVals) ) ] <- as.matrix( currentVals[ tags[nospawn,1], ] )	
		}
	}
	tags  
}        


# This function removes Fish and BOTS that have made it to the spawning grounds
.spawn <- function( CU, t, saveBOTS = FALSE, saveTags = FALSE ){
  # The spawning grounds
  spawnR <- max( CU$reach[[1]] )
  # Remove spawning BOTS
  if( saveBOTS ){
	if( is.null( "CU$spawnedBOTS" ) ) CU$spawnedBOTS <- CU$bots[ numeric(0), ]
	CU$spawnedBOTS <- rbind( CU$spawnedBOTS, CU$bots[ CU$bots[,1] == spawnR & !is.na( CU$bots[,1] ), , drop = FALSE] )
  }
  CU$bots[ CU$bots[,1] == spawnR & !is.na( CU$bots[,1] ), ] <- NA
  # Remove spawning tags
  sptags <- 0
  if( !is.null( CU$tags ) ){
	  CU$bots[,1] == spawnR & !is.na( CU$bots[,1] )
    sptags <- sum( as.numeric( CU$tags[,1] == spawnR ), na.rm = TRUE )
	if( saveTags ){
	  if( is.null( "CU$spawnedTags" ) ) CU$spawnedTags <- CU$tags[ numeric(0), ]
	  CU$spawnedTags <- rbind( CU$spawnedTags, CU$tags[ CU$tags[,1] == spawnR & !is.na( CU$tags[,1] ), , drop = FALSE ] )
	}
    CU$tags[ CU$tags[,1] == spawnR, 1 ] <- 0
  }
  # Remove spawning fish and keep track of those removed
  CU$spawners[t] <- sum( CU$N[ spawnR, ] ) + sptags
  CU$N[ spawnR, ] <- 0                            
  CU
}


count.obs <- function( CU, rb.func = NULL, cv = 0, ... ){
  # This function gets fish passage estimates
  #
  # Inputs:
  # The CU object containing true fish passage ($counts)
  # A function to apply bias as a function of true counts (should take true
  #   counts as first argument, and return biased counts)
  # A coefficient of variation for lognormal observation errors (recycled)
  # '...' will be passed to rb.func
  if( is.null( rb.func ) ) rb.func <- function( x, ... ) x
  cv <- rep( cv, length.out = ncol( CU[[1]]$counts ) )
  
  # Extract the true fish passage by CU
  counts <- list()
  for( station in 1:ncol( CU[[1]]$counts ) ){
    counts[[station]] <- rowSums( sapply( CU
			, FUN = function( x, i ) x$counts[,i], i = station ) )
  }
  counts <- as.data.frame( counts )
  names( counts ) <- colnames( CU[[1]]$counts )
  
  # Apply bias to counts
  counts <- sapply( counts, FUN = rb.func, ... )
  
  # Apply error to biased counts
  errfun <- function( x, cv ){
    sig <- min( 0, sqrt( log( cv*cv + 1 ) ), na.rm = TRUE )
    rlnorm( length(x), meanlog = log( x ) - sig*sig/2, sdlog = sig )   
  }
  for( i in 1:ncol( counts ) ) counts[,i] <- errfun( counts[,i], cv = cv[i] )
counts   
}

# A function that extracts the numbers by reach and CU
Next <- function( x, r ){
  if( is.matrix( x$N ) ){ out <- x$N[r,]
  }else{ out <- x$N[r] }
out
}

relAbun.obs <- function( CU, reach, q, cvq
	    , skill = diag( 1, nrow = length( CU ), ncol = length( CU ) ) ){
  # This function gets a relative abundance estimate at a particular location
  # (from a test fishery or counting wheel, for example).
  # It also estimates population proportions at a particular location
  #
  # Inputs:
  # The CU object containing true abundances
  # The reach
  # The catchability (proportion sampled) by CU (recycled)
  # The catchability error by CU (recycled) - q's are drawn from a beta() dist'n
  # A correlation matrix specifying stock identification rates
  if( any( q < 0 ) | any( q > 1 ) ) stop( "Average catchability must be between zero and one!" )
  q <- rep( q, length.out = length(CU) )
  cvq <- rep( cvq, length.out = length(CU) )
  
  # Draw catchabilities
  if( any( cvq > 0 ) ){
    sdq <- cvq * q
    alph <- q*( q*(1-q)/(sdq*sdq) - 1 )
    bet <- (1-q)*( q*(1-q)/(sdq*sdq) - 1 )
    qdraw <- rbeta( length(q), shape1 = alph, shape2 = bet )
  }else{
  qdraw <- q
  }
  qdraw[ is.na(qdraw) ] <- q[ is.na(qdraw) ]
  q <- qdraw
  # Extract numbers sampled by CU
  N <- sapply( CU, Next, r = reach )
  if( is.matrix( N ) ) N <- colSums( N )
  if( any( q != 1 ) ) N <- rbinom( length(N), N, q )

  if( sum(N) > 0 ){ 
    # Go by CU and get the IDs
    ID <- matrix( NA, nrow = length(CU), ncol = length(CU) )
    CUnames <- character( length(CU) )
    for( i in 1:length(CU) ){
      ID[ i, ] <- rmultinom( 1, N[i], skill[ i, ] )
      CUnames[i] <- CU[[i]]$CUname
    }
    ID <- colSums( ID )
    props <- ID / sum( ID )
  }else{
    props <- rep(0, length(N))
    CUnames <- character( length(CU) )
    for( i in 1:length(CU) ) CUnames[i] <- CU[[i]]$CUname
  }                 
  names(props) <- CUnames
  
return( list( N = sum(N), props = props ) )
}


tagFish.obs <- function( CU, tags, reach, stoch = TRUE, weights = 1 ){
  # This function applies tags to fish, effectively removing them from a
  # CU's population pool and placing them in a $tags object.  They are then
  # kept track of using BOTS functions, except that they are not repopulated.
  # A simplifying assumption is made that the absolute number of tags on a
  # CU is much less than the CU abundance, so that tagged fish are not counted
  # in catch calculations (i.e. they are treated the same way that BOTS are
  # for catch calculations).
  #
  # The tags are applied using a multinomial catch (if stoch = TRUE )
  # or in direct proportion to abundance (if stoch = FALSE )
  #
  # Tag detections are handled by the moveCL function
  #
  # Inputs:
  # The CU object containing all of the CUs
  # The total number of tags deployed
  # The reach where the tagging takes place

  # The number of states being kept track of
  nstates <- ncol( CU[[1]]$bots ) - 2

  # Calculate the number of tags to apply to each CU
  
  # Get the numbers by CU and reach
  N <- sapply( CU, Next, r = reach )
  # Recycle weights
  weights <- rep( weights, length.out = length(CU) )
  weights <- matrix( weights, nrow = nrow(N), ncol = ncol(N), byrow = TRUE )
  
  # If there aren't any fish there
  if( sum( N ) > 0 ){
    if( stoch ){
      tagMat <- matrix( rmultinom( 1, tags, as.vector( N )*weights ), nrow = nrow( N ) )
      tagMat <- pmin( tagMat, N ) # Can't tag more than are there
    }else{
      Ntot <- sum( N )
      tagMat <- pmin( round( tags * weights * N / Ntot ), N ) # Can't tag more than are there
    }
    # Format to be the same as BOTS format: "reach" "path" "state"
    # The "tag code" will be stored in the row names
    # Get the current maximum tag number for all CUs
    tagno <- max( unlist( sapply( CU, function( x ) as.numeric( rownames( x$tags ) ) ) ), 0 )
    for( i in 1:length( CU ) ){  # Loop over the number of CUs
      for( j in 1:nrow( tagMat ) ){  # Loop over the number of paths
	newtags <- cbind( rep( reach, tagMat[j,i] ), rep( j, tagMat[j,i] ) )
	if( nrow( newtags ) > 0 ){
	  newtags <- cbind( newtags
			 , .getStates( n = tagMat[j,i]
				    , bots = CU[[i]]$bots
				    , reach = reach
				    , path = j
				    , fullpath = CU[[i]]$reach[[j]]
				    , stoch = stoch
				    )
			)
	  newtags <- na.omit( newtags )
	  if( any(newtags[,3]<0 | newtags[,3]>200) ) browser()
	  if( nrow(newtags) > 0 ){
	    rownames( newtags ) <- seq( from = tagno + 1, to = tagno + nrow( newtags ), by = 1 )
	    tagno <- tagno + nrow( newtags )  # Increment the tag ID number
	    CU[[i]]$tags <- rbind( CU[[i]]$tags, newtags )  # Add the tags
	    # Remove tagged fish from the general population
	    CU[[i]]$N[reach,j] <- CU[[i]]$N[reach,j] - tagMat[j,i]
	  }
	}
      }
    }
  }
CU  
}

tagsAccumulate <- function( tags.mat = NULL, CU, t ){
  # This function accumulates tags info into a large matrix for later use

  # Function that grabs the CU and tags info
  gt <- function( x, t ){
	if( !is.null( x$tags ) ) out <- cbind( t, x$CU, x$tags )
	else out <- NULL
  out
  }
  # Get the CU and tags info and rbind it to a matrix
  tags.curr <- do.call( rbind, lapply( CU, gt, t ) )
  tags.curr.mat <- NULL
  if( !is.null( tags.curr ) ){
    # Add a column for the tag ID from the rownames
    tags.curr.mat <- matrix( c( as.numeric( rownames( tags.curr ) ), tags.curr )
                    , nrow = nrow( tags.curr ) )
    colnames( tags.curr.mat ) <- c( "ID", "t", "CU", "Reach", "Path"
                    , paste( "State.", 1:(ncol(tags.curr.mat)-5), sep = "" ) )
  }
# Append
rbind( tags.mat, tags.curr.mat )
}

tagsGenerate <- function( retSplit, nTags, cuN ){
  # This function generates tag deployments according to the
  # timing distribution of fish
  nCU <- length( retSplit )
  nP <- length( retSplit[[1]] )
  nTags <- rep( nTags, length.out = nCU )
  out <- retSplit
  for( i in 1:nCU ){
	for( j in 1:nP ){
	  out[[i]][[j]] <- round( pmax( retSplit[[i]][[j]]/cuN[[i]]*nTags[i], 0, na.rm = TRUE ) )
	}
  }
out
}




.getStates <- function( n, bots, reach, path, fullpath, stoch = TRUE, bounded = TRUE ){
  # First, get the bots that are in the reach
  cbots <- na.omit( bots[ bots[,1] == reach & bots[,2] == path, ] )
  # The number of states
  nstates <- ncol( bots ) - 2
  # The output objects (states)
  st <- matrix( NA, nrow = n, ncol = nstates )
  # If there are bots, then great
  haveBots <- nrow( cbots ) > 0
  if( haveBots ){
    if( stoch ){
      for( i in 1:nstates ) st[,i] <-  quantile( cbots[,2+i], runif(n), type = 4 )
    }
    if( !stoch ){
      for( i in 1:nstates ) st[,i] <- mean( cbots[,2+i] )
    }
  }
  if( !haveBots ){
    # OK, so there aren't any bots to use.  We need a failsafe way to proceed.
    # Some sort of interpolation is likely best here.
    # Need to interpolate the mean value and standard deviation too
      # NOTE: we assume that the state values are normally distributed
    
    # Calculate the xvalues for use in interpolation.  Note that these need to
    # refer to the index of the migration path, not the river reach.  This is
    # because the migration path won't be continuous in river reach number.
    xv <- unlist( sapply( bots[ bots[,2] == path, 1 ], function(x) which( fullpath == x ) ) )
    # Our xvalues for the st dev calculations are unique
    xv2 <- which( fullpath %in% unique( bots[ bots[,2] == path , 1 ] ) )
	for( i in 1:nstates ){
	  if( length(xv) > 1 ){
        # When interpolating the mean value, our yvalues are just the state values
        yv <- na.omit( bots[ bots[,2] == path , i + 2 ] )
        # approx does the interpolation
        meanstate <- approx( xv, yv, xout = which( fullpath == reach ), rule = 1 )$y
		if( any( is.na( meanstate ) ) ) warning( "State unavailable for one or more reaches outside of BOTS coverage" )
		# if we aren't dealing with stochasticity, all states will be = meanstate
        if( !stoch ) st[,i] <- meanstate
        # st dev is a bit more tricky because we need to calculate sd's first
        yv2 <- aggregate( bots[ bots[,2] == path , i + 2 ]
	   	       , by = list( bots[ bots[,2] == path , 1 ] )
		       , FUN = sd, na.rm = TRUE )$x
        yv2[is.na(yv2)] <- 0
        # approx does the interpolation - bounded to (0,max(yv))
        sdstate <- min( max( approx( xv2, yv2, xout = which( fullpath == reach ), rule = 2 )$y, 0, na.rm = TRUE ), max( yv2, na.rm = TRUE ) )
        # if we are dealing with stoch, states will be drawn from rnorm()
        if( stoch & !bounded ) st[,i] <- suppressWarnings( rnorm( n, meanstate, sdstate ) )
		if( stoch & bounded ) st[,i] <- pmin( pmax( suppressWarnings( rnorm( n, meanstate, sdstate ) ), min(yv, na.rm = TRUE), na.rm = TRUE ), max(yv, na.rm = TRUE) )
      }
	  # If there is only one lonely BOTS, then we should use it
	  if( length(xv) == 1 ) st[,i] <- na.omit( bots[ bots[,2] == path , i + 2 ] )
    }# If there are not BOTS to be had, return NA
  }
st
}

.listentags <- function( newtags, oldtags, stations, reaches ){
  # This function listens for tags, recording the tag ID number
  # at which the tags pass the listening station node
  # The result is a list of tag IDs that is the same length as 'stations'

  # newtags is the tags matrix post-movement
  # oldtags is the tags matrix pre-movement
  # stations is a vector of the listening station locations
  # reaches is a list with vectors containing the unique migration paths

  passed <- vector( mode = "list", length = length( stations ) ) 
  for( i in 1:length( passed ) ) passed[[i]] <- NA
  
  # Line up the new and old tags in case they don't match up
  # (e.g. if there are new tags in the population)
  if( nrow( newtags ) > 1 & nrow( oldtags ) > 1 ){ #If there is more than one tag
    newtags <- newtags[ match( rownames( oldtags ), rownames( newtags ) ), ]
    oldtags <- oldtags[ match( rownames( newtags ), rownames( oldtags ) ), ]  
  }else{ # If there is only one tag, then we have to check to see if the before
         # and after rownames match.  If they do, then carry on.  If not, then we
         # need to determine which of newtags and oldtags have only one row,
         # and then get the matching tag from the other.
    if( !all( nrow( newtags ) == 1, nrow( oldtags ) == 1, rownames( newtags ) == rownames( oldtags ) ) ){
      if( nrow( newtags ) == 1 ){
	oldtags <- oldtags[ rownames( oldtags ) == rownames( newtags ), ]
	rn <- rownames( newtags )[ length( oldtags ) > 0 ]
	oldtags <- matrix( oldtags, ncol = ncol( newtags )
			  , dimnames = list( rn, colnames( newtags ) ) )
      }
      if( nrow( oldtags ) == 1 ){
	newtags <- newtags[ rownames( newtags ) == rownames( oldtags ), ]
	rn <- rownames( oldtags )[ length( newtags ) > 0 ]
	newtags <- matrix( newtags, ncol = ncol( oldtags )
			  , dimnames = list( rn, colnames( oldtags ) ) )
      }
    }
  }
  if( nrow( newtags ) + nrow( oldtags ) == 0 ){
    passed <- 0
  }else{
  # In order for a tag to have passed a listening station, it must have a
  # current location that is beyond the station, and a past location that is
  # before the station.
  # We need to do this comparison for each of the paths on our map, because
  # some station locations might be on one path but not another.
  for( path in 1:length( reaches ) ){
    # Where are the stations on the path?
    st.path <- match( stations, table = reaches[[path]] )
    # Where are the tags on the path?
    new.path <- match( newtags[ newtags[,2] == path, 1 ], table = reaches[[path]] )
    names( new.path ) <- rownames( newtags )[ newtags[,2] == path ]
    old.path <- match( oldtags[ oldtags[,2] == path, 1 ], table = reaches[[path]] )
    names( old.path ) <- names( new.path )
    if( any( is.na( c( new.path, old.path ) ) ) ) stop( "There's something wrong with tag paths/locations")
    # Which tags have gone past the stations?
    for( st in 1:length( stations ) ) passed[[st]] <- c( passed[[st]], names( new.path )[ new.path >= st.path[st] & old.path < st.path[st] ] ) 
  }
  passed <- lapply( passed, function(x) x[!is.na(x)] )
}
passed
}


.doObs <- function( obsDesign, t ){
  # This function takes an observational design and implements it.
  # The idea here is to read in a design from file, and provide
  # that data.frame as the argument obsDesign.  Then, at each timestep in
  # FSmodRun, this function is called and a list of expressions is evaluated
  # in the FSmodRun environment.
  # Critical to proper operation is the appropriate inclusion of arguments
  # to the observation functions as well as appropriate assignments.
  # Things could go very wrong... Hopefully, this works!
  # Make sure that the obsDesign data.frame has timestep in column 1 and
  # the expression to be evaluated in column 2
  
  # First, extract the text string representations of the expressions
  obsTimes <- obsDesign[ , 1]
  obsTimes <- lapply( parse( text = obsTimes ), eval )
  thisTime <- sapply( obsTimes, FUN = function( x, t ) t %in% x, t = t )
  ex <- obsDesign[ thisTime, 2 ]
  if( length( ex ) > 0 ){
    # Convert to expressions and evaluate, one at a time
    ex <- parse( text = ex )
    for( i in 1:length(ex) ) eval.parent( ex[[i]] )
  }
0
}

.doMan <- function( manPlan ){
	# This function takes an in-season management plan and implements it.
	# The idea here is to read in a plan from file, and provide
	# that data.frame as the argument manPlan.  Then, at each timestep in
	# FSmodRun, this function is called and a list of expressions is evaluated
	# in the FSmodRun environment.
	# Critical to proper operation is the appropriate inclusion of arguments
	# to the management functions as well as appropriate assignments.
	# Things could go very wrong... Hopefully, this works!
	# Make sure that the manPlan data.frame has a conditional statement in 
	# column 1 and the expression to be evaluated in column 2
	
	# Check which conditions are true...
	mPl <- parse( text = manPlan[,1] )
  mPLogic <- logical( length( mPl ) )
	for( i in 1:length( mPl ) ) mPLogic[i] <- eval.parent( mPl[i] )
	# Extract the text string representations of the expressions
	ex <- manPlan[ mPLogic, 2 ]
	if( length( ex ) > 0 ){
		# Convert to expressions and evaluate, one at a time
		ex <- parse( text = ex )
		for( i in 1:length(ex) ) eval.parent( ex[[i]] )
	}
0
}


getFSmodFiles <- function( wd = getwd(), libPath = .libPaths(), overwrite = TRUE ){
  # Gets the FSmodFiles from the installation directory and puts them in
  # the working directory.

  # First, figure out where the FSmod folder is
  whereLib <- libPath[ sapply( libPath, function( x ) any( dir( x ) == "FSmod" ) ) ]

  # Check to see if we have found FSmod, or if it exists twice
  if( length( whereLib ) == 0 ) stop( "FSmod not found in any of libPaths")
  if( length( whereLib ) > 1 ){
    cat( "FSmod was found in multiple libPaths! \n" )
    cat( "Choose one of the following libPaths. \n" )
    cat( "These are listed in the order that the FSmod \n" )
    cat( "installations were last modified \n" )
    libinfo <- file.info( paste( whereLib, "FSmod", sep = "/" ) )
    libinfo <- libinfo[ order(libinfo$mtime, decreasing = TRUE), ]
    ch <- paste(row.names(libinfo), libinfo$mtime, sep = ": ")
    thelib <- select.list( ch )
    whereLib <- whereLib[ whereLib == thelib ]
  } 

  # Now, copy to working directory
  theFiles <- paste( whereLib, "/FSmod/FSmodfiles/"
                    , dir( paste( whereLib, "/FSmod/FSmodfiles", sep = "" ) )
                    , sep = "" )
  copied <- file.copy( from = theFiles, to = wd, overwrite = overwrite, recursive = TRUE )
return( copied )
}


plotFSmodOut <- function( out.df = NULL, fn = NULL, CU, cuN, plotBOTS = FALSE
			  , whichCU = NULL, nPerPage = 2, pdfname = NULL ){
  # A function to plot the migration trajectories of an
  # output from FSmodRun()
  if( is.null( out.df ) ){
    if( is.null( fn ) ) stop( "You need to specify either out.df or fn!" )
    if( !is.null( fn ) ) out.df <- read.table( fn, header = TRUE )
  }else{
	out.df <- as.data.frame( out.df )
  }
  # Subset the out.df object
  if( class( whichCU ) == "logical" ) whichCU <- which( whichCU )
  if( !is.null( whichCU ) ){ out.df <- out.df[ out.df[,"CU"] %in% whichCU, ] }
  else{ whichCU <- 1:length(CU) }
  
  # Figure out how many pages we'll need
  npages <- ceiling( length( whichCU ) / nPerPage )

  # Figure out the maximum number of reaches
  nreachAll <- max( sapply( CU, function(x) length( unique( unlist( x$reach ) ) ) ) )

  # If we are not saving to file, we will use the default grDevice.  Otherwise, .pdf
  X11true <- FALSE
  if( is.null( pdfname ) ) X11true <- TRUE
  
  # Build all of the plotting data.frames beforehand so that we don't have to wait later
  datN <- vector( length = length( whichCU ), mode = "list" )
  datC <- vector( length = length( whichCU ), mode = "list" )
  datM <- vector( length = length( whichCU ), mode = "list" )
  
  cat( "plotFSmodOut: Reshaping data for plotting" )
  
  for( j in 1:length( whichCU ) ){
    cat(".")
    thisCU <- whichCU[j]
    dat <- out.df[ out.df[,"CU"] == thisCU, ]
	out.df.names <- names( out.df )
    # First, do the numbers
    datr <- reshape( dat, direction = "wide", timevar = "t", idvar = "reachid"
		   , drop = out.df.names[ !(out.df.names %in% c("t", "reachid", "N")) ] )
    datr <- datr[ datr$reachid %in% unlist( CU[[thisCU]]$reach ), ]
    datr <- datr[ order( datr$reachid ), ]
    rownames( datr ) <- datr$reachid
    colnames( datr ) <- sapply( strsplit( colnames( datr ), ".", fixed = TRUE ), function(x) x[2] )
    datr <- as.matrix( datr[,-1] )
    tsteps <- apply( datr, 2, function( x ) sum(x) > 0 )
    datr <- datr[, tsteps ]
    # datr <- rbind( datr, matrix( 0, nrow = nreachAll - nrow( datr ), ncol = ncol( datr ) ) )
    datN[[j]] <- datr
    # Next, do the catches
    datr <- reshape( dat, direction = "wide", timevar = "t", idvar = "reachid"
		   , drop = out.df.names[ !(out.df.names %in% c("t", "reachid", "C")) ] )
    datr <- datr[ datr$reachid %in% unlist( CU[[thisCU]]$reach ), ]
    datr <- datr[ order( datr$reachid ), ]
    rownames( datr ) <- datr$reachid
    colnames( datr ) <- sapply( strsplit( colnames( datr ), ".", fixed = TRUE ), function(x) x[2] )
    datr <- as.matrix( datr[,-1] )
    datr <- datr[, tsteps ]
    # datr <- rbind( datr, matrix( 0, nrow = nreachAll - nrow( datr ), ncol = ncol( datr ) ) )
    datC[[j]] <- datr
    # Finally, do the natural mortality
    datr <- reshape( dat, direction = "wide", timevar = "t", idvar = "reachid"
		   , drop = out.df.names[ !(out.df.names %in% c("t", "reachid", "m")) ] )
    datr <- datr[ datr$reachid %in% unlist( CU[[thisCU]]$reach ), ]
    datr <- datr[ order( datr$reachid ), ]
    rownames( datr ) <- datr$reachid
    colnames( datr ) <- sapply( strsplit( colnames( datr ), ".", fixed = TRUE ), function(x) x[2] )
    datr <- as.matrix( datr[,-1] )
    datr <- datr[, tsteps ]
    # datr <- rbind( datr, matrix( 0, nrow = nreachAll - nrow( datr ), ncol = ncol( datr ) ) )
    datM[[j]] <- datr
  }
  cat("done! \n")

  # Start the plotting
  if( !X11true ) pdfacro( pdfname, width = 6, height = nPerPage*3 )
  for( page in 1:npages ){
    if( X11true ){
      dfunc <- options("device")$device
      if( class(dfunc) == "function" ){
        dfunc( width = 6, height = nPerPage*3 )
      }else{
        X11( width = 6, height = nPerPage*3 )
      }
    }
    par( mfrow = c( nPerPage, 3 ) )
    for( j in ( 1:nPerPage ) + nPerPage*(page-1) ){
      thisCU <- whichCU[j]
      if( is.na( thisCU ) ) next
      if( cuN[[thisCU]] > 0 ){
	# First, plot the Numbers
        # Get the length of the longest node label
        llab <- max( nchar( CU[[thisCU]]$nodes[,1] ) )/2
	par( mar = c( llab, 4, 4, 2 ) + 0.1 )
        plot( 1, 1, type = "n", axes = FALSE
            , xlab = ""
	    , ylab = "Timestep"
	    , main = paste( CU[[thisCU]]$CUcommon, " Numbers", sep = ":" )
#          , xlim = c( 0, max( nrow( datN[[j]] ), ncol( datN[[j]] ) ) )
#          , ylim = c( 0, max( nrow( datN[[j]] ), ncol( datN[[j]] ) ) )
          , xlim = c( 0, nrow( datN[[j]] ) )
          , ylim = range( as.numeric( dimnames( datN[[j]] )[[2]] ) )
          )
      # Generate axis labels
      # Remap to the plot x-axis
      
      # This is how "high" the node names will be
      shigh <- max( strheight( CU[[thisCU]]$nodes[,1] ) )/1.2
      # Remove those labels that are too close to the previous
      labs <- CU[[thisCU]]$nodes
      labs[,2] <- match( labs[,2], dimnames( datN[[j]] )[[1]] )
      labsnew <- labs[1,]
      for( k in 2:nrow(labs) ){
	if( ( labs[k,2] - labsnew[nrow(labsnew),2] ) > shigh ) labsnew <- rbind( labsnew, labs[k,] )
      }
      labs <- labsnew
      # Make x-axis, with appropriate labels
      axis( 1, at = labs[,2], labels = labs[,1], las = 2 )
      # Make y-axis, with appropriate labels
      axis( 2, las = 2 )
      box()
      abline( h = seq( 10*floor( min( as.numeric( dimnames( datN[[j]] )[[2]] ) )/10 ) 
		     , max( as.numeric( dimnames( datN[[j]] )[[2]] ) )
		     , by = 10 )
            , col = "lightblue", lwd = 0.5 )
      abline( v = seq( 1, nrow( datN[[j]] ), by = 10 )
            , col = "lightblue", lwd = 0.5 )
	image( 1:nrow( datN[[j]] ), as.numeric( dimnames( datN[[j]] )[[2]] ), datN[[j]]
          , col = c( rgb( 1,1,1,0 ), gray( (7:0)/10 ) ), add = TRUE
	  , breaks = c( -0.5, 0.5, seq( min( datN[[j]] ) + 1, max( datN[[j]] ) + 1, length.out = 8 ) )
          )
	usr <- par( "usr" )
	mtext( paste( "Returns =", cuN[[thisCU]] ), 3, -1, cex = 0.6 )
	mtext( paste( "Spawn Escapement =", round( sum( CU[[thisCU]]$spawners ) ) ), 3, -2, cex = 0.6 )

	# Now, plot the catches
	cols <- c( rgb( 1,1,1,0 ), gray( (7:0)/10 ) )
      plot( 1, 1, type = "n", axes = FALSE
          , xlab = ""
	    , ylab = "Timestep", main = paste( CU[[thisCU]]$CUcommon, " Catch", sep = ":" )
#          , xlim = c( 0, max( nrow( datC[[j]] ), ncol( datC[[j]] ) ) )
#          , ylim = c( 0, max( nrow( datC[[j]] ), ncol( datC[[j]] ) ) )
          , xlim = c( 0, nrow( datC[[j]] ) )
          , ylim = range( as.numeric( dimnames( datC[[j]] )[[2]] ) )
	  )
      axis( 1, at = labs[,2], labels = labs[,1], las = 2 )
      axis( 2, las = 2 )
      box()
      abline( h = seq( 10*floor( min( as.numeric( dimnames( datC[[j]] )[[2]] ) )/10 )
		     , max( as.numeric( dimnames( datC[[j]] )[[2]] ) )
		     , by = 10 )
            , col = "lightblue", lwd = 0.5 )
      abline( v = seq( 1, nrow( datC[[j]] ), by = 10 )
            , col = "lightblue", lwd = 0.5 )
      if( sum( datC[[j]] ) > 0 ){
        image( 1:nrow( datC[[j]] ), as.numeric( dimnames( datC[[j]] )[[2]] )
	    , datC[[j]], col = cols, add = TRUE
	    , breaks = c( -0.5, 0.5, seq( min( datC[[j]] ) + 1, max( datC[[j]] ) + 1, length.out = 8 ) )
	    )
      }
	usr <- par( "usr" )
	mtext( sum( datC[[j]] ), 3, -1, cex = 0.6 )
	# Finally, plot the natural mortality
	cols <- c( rgb( 1,1,1,0 ), gray( (7:0)/10 ) )
      plot( 1, 1, type = "n", axes = FALSE
          , xlab = ""
	    , ylab = "Timestep", main = paste( CU[[thisCU]]$CUcommon, " N. Mortality", sep = ":" )
#          , xlim = c( 0, max( nrow( datM[[j]] ), ncol( datM[[j]] ) ) )
#          , ylim = c( 0, max( nrow( datM[[j]] ), ncol( datM[[j]] ) ) )
          , xlim = c( 0, nrow( datM[[j]] ) )
          , ylim = range( as.numeric( dimnames( datM[[j]] )[[2]] ) )
          )
      axis( 1, at = labs[,2], labels = labs[,1], las = 2 )
      axis( 2, las = 2 )
      box()
      abline( h = seq( 10*floor( min( as.numeric( dimnames( datM[[j]] )[[2]] ) )/10 ) 
		     , max( as.numeric( dimnames( datM[[j]] )[[2]] ) )
		     , by = 10 )
            , col = "lightblue", lwd = 0.5 )
      abline( v = seq( 1, nrow( datM[[j]] ), by = 10 )
            , col = "lightblue", lwd = 0.5 )
      if( sum( datM[[j]] ) > 0 ){
	image( 1:nrow( datM[[j]] ), as.numeric( dimnames( datM[[j]] )[[2]] )
	      , datM[[j]], col = cols, add = TRUE
	      , breaks = c( -0.5, 0.5, seq( min( datM[[j]] ) + 1, max( datM[[j]] ) + 1, length.out = 8 ) )
	      )
      }
	usr <- par( "usr" )
	mtext( sum( datM[[j]] ), 3, -1, cex = 0.6 )
    }else{
      plot.new()
      plot( c(1,2), c(1,2), type = "n", axes = FALSE
	   , ylab = "", xlab = "", main = CU[[thisCU]]$CUcommon )
      usr <- par( "usr" )
      text( mean( usr[1:2] ), 0.9*usr[4], "No Returns", cex = 1.6 )
      plot.new()
    }
  }
  }
  if( !X11true ) dev.off.acro( pdfname )
}

plotFSmodOut.interactive <- function( out.df = NULL, fn = NULL, CU, cuN
				      , whichCU = NULL, intNodes = "Mission", type = c("barplot", "line") ){
  # An interactive plotting function to to examine the migration trajectories
  # of an output from FSmodRun()
  if( is.null( out.df ) ){
    if( is.null( fn ) ) stop( "You need to specify either out.df or fn!" )
    if( !is.null( fn ) ) out.df <- read.table( fn, header = TRUE )
  }
  type <- match.arg( type )

  notdone <- TRUE
  continue <- FALSE
  while( notdone ){
    # If whichCU is specified, then great.  Otherwise, ask which CU the user
    # wants to examine.
    if( !continue ){
      if( is.null( whichCU ) ){
	cat( "\n CU to examine is not specified... Please choose: \n" )
	for( i in 1:length( CU ) ) cat( i, ". ", CU[[i]]$CUname, " - ", CU[[i]]$CUcommon, "\n", sep = "" )
	choice <- 0
	while( !( choice %in% 1:length( CU ) )  ){
	  cat( "Enter the number of the CU you want to examine from the list: \n" )
	  choice <- scan( what = integer(0), n = 1, quiet = TRUE )
	}
      }else{
	if( class( whichCU ) == "logical" ) whichCU <- which( whichCU )
	choice <- whichCU[1]
      }
      if( cuN[[choice]] > 0 ){
	# Subset the out.df to "choice"
	dat <- as.data.frame( out.df[ out.df[,"CU"] == choice, ] )
	# Build all of the plotting data.frames beforehand so that we don't have to wait later
	cat( "plotFSmodOut.interactive: Reshaping data for plotting... " )
	dat.names <- names( dat )
	# Reshape the data
	datr <- reshape( dat, direction = "wide", timevar = "t", idvar = "reachid"
		       , drop = dat.names[ !(dat.names %in% c("t", "reachid", "N")) ] )
	# Trim the superfluous reaches
	datr <- datr[ datr$reachid %in% unlist( CU[[choice]]$reach ), ]
	datr <- datr[ order( datr$reachid ), ]
	rownames( datr ) <- datr$reachid
	# Trim the superfluous timesteps
	colnames( datr ) <- sapply( strsplit( colnames( datr ), ".", fixed = TRUE ), function(x) x[2] )
	datr <- as.matrix( datr[,-1] )
	tsteps <- apply( datr, 2, function( x ) sum(x) > 0 )
	datr <- datr[, tsteps ]
	cat("done! \n")
      }
    }#end if( continue )
  dfunc <- options("device")$device
  if( class(dfunc) == "function" ){
    dfunc()
  }else{
    X11()
  }
    par( mfrow = c(2,2) )
    # Plot the numbers image, leaving space for profile plots
      if( cuN[[choice]] > 0 ){
        # Statistics in the bottom right
        plot.new(); plot.new(); plot.new()
	
        plot( c(1,2), c(1,2), type = "n", axes = FALSE
            , ylab = "", xlab = "", main = CU[[choice]]$CUcommon )
        usr <- par( "usr" )
	par( xpd = NA )
	yv <- seq( .96, 0, -0.04 )
        text( mean( usr[1:2] ), yv[1]*usr[4], pos = 3, "Fates", font = 2 )
        text( mean( usr[1:2] ), yv[2]*usr[4], pos = 3
	     , paste( "Returns =", cuN[[choice]]
		     , "   Spawners =", round( sum( CU[[choice]]$spawners ) ) ) )
	text( mean( usr[1:2] ), yv[3]*usr[4], pos = 3
	     , paste( "Total Catch =", sum( dat[ dat[,"CU"] == choice , "C" ] )
		     , "   En-route Mortality =", sum( dat[ dat[,"CU"] == choice , "m" ] ) ) )
        # Spawn escapement range, mean, and peak
        text( mean( usr[1:2] ), yv[4]*usr[4], pos = 3, "Spawn timing", font = 2 )
        text( mean( usr[1:2] ), yv[5]*usr[4], pos = 3
	     , paste( "First arrival =", min( which( CU[[choice]]$spawners > 0 ) )
		     , "   Last arrival =", max( which( CU[[choice]]$spawners > 0 ) ) ) )
        text( mean( usr[1:2] ), yv[6]*usr[4], pos = 3
	     , paste( "Mean arrival =", round( sum( CU[[choice]]$T * CU[[choice]]$spawners )/sum( CU[[choice]]$spawners ) )
		     , "   Peak arrival =", CU[[choice]]$T[ which.max( CU[[choice]]$spawners ) ] ) )
        # Harvest rates by interval (using intNodes)
        text( mean( usr[1:2] ), yv[7]*usr[4], pos = 3, "Harvest Rates", font = 2 )
	  # Get the node id numbers
	  iN <- CU[[choice]]$nodes[ CU[[choice]]$nodes$NODES %in% intNodes, 2 ]
	  iN <- sort( unique( c( iN, max( unlist( CU[[choice]]$reach ) ) ) ) )
	  # Calculate catches by interval, make names for intervals
          for( u in 1:length( iN ) ){
	    if( u == 1 ){
	      ctch <- sum( dat[ dat[,"CU"] == choice & dat[,"reachid"] < iN[u], "C" ] )
	      ctchname <- paste( "Start -", CU[[choice]]$nodes$NODES[ CU[[choice]]$nodes$REACHID == iN[u] ] )
	    }
	    if( u > 1 ){
	      ctch <- sum( dat[ dat[,"CU"] == choice & dat[,"reachid"] < iN[u] & dat[,"reachid"] >= iN[u-1], "C" ] )
	      ctchname <- paste( CU[[choice]]$nodes$NODES[ CU[[choice]]$nodes$REACHID == iN[u-1] ]
			       , "-", CU[[choice]]$nodes$NODES[ CU[[choice]]$nodes$REACHID == iN[u] ] )
	    }
	    if( u == length( iN ) ){
	      ctch <- sum( dat[ dat[,"CU"] == choice & dat[,"reachid"] < iN[u] & dat[,"reachid"] >= iN[u-1], "C" ] )
	      ctchname <- paste( CU[[choice]]$nodes$NODES[ CU[[choice]]$nodes$REACHID == iN[u-1] ]
			       , "- End" )
	    }
	    text( mean( usr[1:2] ), yv[u+7]*usr[4], pos = 3, paste( ctchname, "=", signif( ctch/cuN[[choice]], 3 ) ) )
	  }
	
        # En-route mortality by interval (using intNodes)
	text( mean( usr[1:2] ), yv[length(iN)+8]*usr[4], pos = 3, "En-route N. Mortality", font = 2 )
	  # Calculate enroute mortality by interval, make names for intervals
          for( u in 1:length( iN ) ){
	    if( u == 1 ){
	      nM <- sum( dat[ dat[,"CU"] == choice & dat[,"reachid"] < iN[u], "m" ] )
	      nMname <- paste( "Start -", CU[[choice]]$nodes$NODES[ CU[[choice]]$nodes$REACHID == iN[u] ] )
	    }
	    if( u > 1 ){
	      nM <- sum( dat[ dat[,"CU"] == choice & dat[,"reachid"] < iN[u] & dat[,"reachid"] >= iN[u-1], "m" ] )
	      nMname <- paste( CU[[choice]]$nodes$NODES[ CU[[choice]]$nodes$REACHID == iN[u-1] ]
			       , "-", CU[[choice]]$nodes$NODES[ CU[[choice]]$nodes$REACHID == iN[u] ] )
	    }
	    if( u == length( iN ) ){
	      nM <- sum( dat[ dat[,"CU"] == choice & dat[,"reachid"] < iN[u] & dat[,"reachid"] >= iN[u-1], "m" ] )
	      nMname <- paste( CU[[choice]]$nodes$NODES[ CU[[choice]]$nodes$REACHID == iN[u-1] ]
			       , "- End" )
	    }
	    text( mean( usr[1:2] ), yv[u+length(iN)+8]*usr[4], pos = 3, paste( nMname, "=", signif( nM/cuN[[choice]], 3 ) ) )
	  }
	
	
	# Now, plot the Numbers
        # Get the length of the longest node label
        llab <- max( nchar( CU[[choice]]$nodes[,1] ) )/2
	par( mar = c( llab, 4, 4, 2 ) + 0.1, mfg = c( 1, 1 ), xpd = FALSE )
        plot( 1, 1, type = "n", axes = FALSE
            , xlab = ""
	    , ylab = "Timestep"
	    , main = paste( CU[[choice]]$CUcommon, " Numbers", sep = ":" )
            , xlim = c( 0, nrow( datr ) )
            , ylim = range( as.numeric( dimnames( datr )[[2]] ) )
          )
      # Generate axis labels
      # Remap to the plot x-axis
      
      # This is how "high" the node names will be
      shigh <- max( strheight( CU[[choice]]$nodes[,1] ) )/1.2
      # Remove those labels that are too close to the previous
      labs <- CU[[choice]]$nodes
      labs[,2] <- match( labs[,2], dimnames( datr )[[1]] )
      labsnew <- labs[1,]
      for( k in 2:nrow(labs) ){
	if( ( labs[k,2] - labsnew[nrow(labsnew),2] ) > shigh ) labsnew <- rbind( labsnew, labs[k,] )
      }
      labs <- labsnew
      # Make x-axis, with appropriate labels
      axis( 1, at = labs[,2], labels = labs[,1], las = 2 )
      # Make y-axis, with appropriate labels
      axis( 2, las = 2 )
      box()
      abline( h = seq( 10*floor( min( as.numeric( dimnames( datr )[[2]] ) )/10 )
		     , max( as.numeric( dimnames( datr )[[2]] ) )
		     , by = 10 )
            , col = "lightblue", lwd = 0.5 )
      abline( v = seq( 1, nrow( datr ), by = 10 )
            , col = "lightblue", lwd = 0.5 )
	image( 1:nrow( datr ), as.numeric( dimnames( datr )[[2]] ), datr
          , col = c( rgb( 1,1,1,0 ), gray( (7:0)/10 ) ), add = TRUE
	  , breaks = c( -0.5, 0.5, seq( min( datr ) + 1, max( datr ) + 1, length.out = 8 ) )
          )
	usr <- par( "usr" )
	mtext( paste( "Returns =", cuN[[choice]] ), 3, -1, cex = 0.6 )
	mtext( paste( "Spawn Escapement =", round( sum( CU[[choice]]$spawners ) ) ), 3, -2, cex = 0.6 )
 
    # Using locator(), have the user click on the plot
      cat( "Using the graphics cursor, choose a coordinate on the plot \n" )
      xy <- locator( n = 1 )
      xy <- lapply( xy, round )
      xy$x <- min( max( xy$x, 1, na.rm = TRUE ), nrow(datr) )
      xy$y <- min( max( xy$y, min( as.numeric( dimnames( datr )[[2]] ) ), na.rm = TRUE )
		  , max( as.numeric( dimnames( datr )[[2]] ) ) )
      
    # Draw arrows in a crosshair, in time and location
      arrows( par("usr")[1], xy$y, par("usr")[2], xy$y, lwd = 2, col = "darkred" )
      arrows( xy$x, par("usr")[4], xy$x, par("usr")[3], lwd = 2, col = "darkblue" )
    # Plot the profile in time
    if( type[1] == "barplot" ){
      barplot( datr[ , as.numeric( dimnames( datr )[[2]] ) == xy$y ]
	     , xlab = "Location Code", col = "darkred", border = NA
	     , main = paste( "Timestep =", xy$y ) )
    }
    if( type[1] == "line" ){
      plot( datr[ , as.numeric( dimnames( datr )[[2]] ) == xy$y ]
       , xlab = "Location Code", col = "darkred", border = NA
	     , main = paste( "Timestep =", xy$y ), type = "l"
       , ylab = "Numbers", lwd = 2 )
      abline( h = 0, col = rgb( 0,0,0,0.5 ) )  
    }
    # Plot the profile in location
    if( type[1] == "barplot" ){
      barplot( datr[ xy$x,  ], xlab = "Timestep", col = "darkblue", border = NA
	     , main = paste( "Location Code =", dimnames( datr )[[1]][xy$x] ) )
    }
    if(type[1] == "line"){
      plot( datr[ xy$x,  ], xlab = "Timestep", col = "darkblue", border = NA
       , main = paste( "Location Code =", dimnames( datr )[[1]][xy$x] )
       , type = "l", ylab = "Numbers", lwd = 2 )
      abline( h = 0, col = rgb( 0,0,0,0.5 ) )
    }
        
    }else{ # If there aren't any returns
      par( mfrow = c(1,1) )
      plot( c(1,2), c(1,2), type = "n", axes = FALSE
	   , ylab = "", xlab = "", main = CU[[choice]]$CUcommon )
      usr <- par( "usr" )
      text( mean( usr[1:2] ), 0.9*usr[4], "No Returns", cex = 1.6 )
    }
    repeat{
      cat( "Plot another? (Y/N) \n" )
      ans <- scan( what = character(0), n = 1, quiet = TRUE )
      notdone <- switch( ans, y = TRUE, Y = TRUE, n = FALSE, N = FALSE )
      if( length( notdone ) > 0 ) break
    }
    if( notdone ){
      repeat{
	cat( "Continue with current CU? (Y/N) \n" )
	ans <- scan( what = character(0), n = 1, quiet = TRUE )
	continue <- switch( ans, y = TRUE, Y = TRUE, n = FALSE, N = FALSE )
	if( length( continue ) > 0 ) break
      }
    }
  }#end while( notdone )
}

.bn <- function( cpAll, bneck, reaches, cpv ){	
# This function applies a bottleneck to the cpAll
# It returns the modified cpAll object.
	# Penalty that creates the bottleneck - the bigger the value, the more bottleneck occurs
	pen <- bneck$pen    # The current penalty value
	# Offset is for adjusting how large the bottleneck is
	off <- max( bneck$offset, 0 )
	if( bneck$offset < 0 ) warning("You can't specify a bottleneck offset < 0. I've forced the offset = 0.")
	if( bneck$offset > ncol( cpAll )/2 ) warning( paste( bneck$offset, "appears to be a large offset value... strange things may happen..." ) )
	# Get the path to the cutpoint
	path <- .reachPath( r = bneck$loc, rchs = reaches )
	# We want to increase the cutpoints for all paths leading to the bottleneck
	# Get the reaches involved in each path
	if( class( path ) != "list" ) path <- list( path )
	# Complicated looking function that gets the reaches approaching the bottleneck
	# but takes into account that there might not be enough approaching reaches.
	fun1 <- function(x, n, cpAll){
		f <- rep( NA, length( (-ncol(cpAll)+n):(-1) ) )
		g <- x[max( (length(x)-ncol(cpAll)+n), 1 ):(length(x)-1)]
		f[ (length(f)-length(g)+1):length(f) ] <- g
		f
	}
	approach <- sapply( path, fun1, n = which(cpv==0) + off - 1, cpAll = cpAll )
	# Build the lower triangular matrix that will be added
	cpAdd <- matrix( 0, nrow = nrow( approach ), ncol = nrow( approach ) )
	for( i in nrow( cpAdd ):1 ) cpAdd[i,(ncol(cpAdd)-i+1):ncol(cpAdd)] <- pen + i - 1
	# Loop over the approach from each path
	for( i in 1:nrow( approach ) ){
		# For each unique approach reach, add the appropriate row from cpAdd to cpAll
		oldbit <- cpAll[ cpAll$reach %in% approach[i,]
				, (ncol(cpAll)-ncol(cpAdd)+1):ncol(cpAll) ]
		if( nrow( oldbit ) > 0 ){ # This will be FALSE if past the beginning of the map
			newbit <- oldbit + matrix( rep( cpAdd[i,], nrow( oldbit ) )
					, nrow = nrow( oldbit ), byrow = TRUE )
			cpAll[ cpAll$reach %in% approach[i,]
					, (ncol(cpAll)-ncol(cpAdd)+1):ncol(cpAll) ] <- newbit
		}
	}
	cpAll
}




# What are the types of data that can be collected in-season?
# TEST FISHERY DATA
# -------------------
# Test fishery catch (total)
# Test fishery species composition
# Test fishery stock ID (DNA/scale)
# Error structure(s):
# - Stochastic catches
# - Error in catchability
# - Error in species composition estimate
# - Error in stock identification (multinomial? failed IDs?)
#
# COUNTING FENCE DATA
# ---------------------
# Numbers passing (total)
# Future: Species composition from swimming characteristics
# Error structure(s):
# - Error in detection (over or underestimates)
# - Error in species ID (multinomial? failed IDs?)
#
# RADIO TAG DATA
# ----------------
# Individual fish passage past station
# Error structure(s):
# - Missed detections
# - Misread codes?


# How will the assessment work?
# The assessment/management model will probably be simplified as compared to
#   the simulated "truth" (this is not unreasonable - this is the way the real
#   world works!)
# For starters, we can use the framework suggested in the workshop report
#
# - Begin with a preseason forecast. This is generated by running the full
#   simulation once, using "average" parameter values, and extracting the
#   information needed to get a first cut estimate of the run.
# - Based on this first-cut estimate, a pattern of fishery openings (in the
#   form of a harvest rate matrix) will be calculated that will meet
#   objectives.
# - The simulation model will then be run "for real", with data collection
#   being conducted as the simulation progresses.  Each new piece of information
#   will be used to update the pre-season forecast.
# - Fishery openings (i.e. the harvest rate matrix) will also be updated as the
#   simulation progresses each time that additional information is collected.
#   Of course, only the portion of the harvest rate matrix that lies in the
#   future will be available for modification.

