FSmodRun <- function( cl = NULL, nProcs = 1, plotTF = TRUE, plotTFinteract = TRUE
                    , plotPars = list( plotBOTS = FALSE, whichCU = NULL
                                      , nPerPage = 2, pdfname = NULL, itype = "barplot" )
                    , buildX = TRUE, yRead = TRUE, loadY = FALSE
                    , mvr.file = "move/moveRates02.txt", N.file = "CU/RunSize.csv"
                    , CUdefs.file = "CU/CUdefns.csv", mvdefs.file = "move/moveDefns02.csv"
                    , year.N = 2002, nT = 360, nBots = 1000, nStates = 1, keepStates = 14
                    , reachNodes.file = "basemap/ReachNodes.csv"
                    , reachDefs.file = "basemap/ReachDefns.csv"
                    , retdist.file = NULL
                    , retpars = list( func = function( x, p ) dnorm( x, p[1], p[2] )
                                    , file = "CU/2002ArrT.csv"
                                    , CU.col = 2, par.col = c(5,3)
                                    , par.trans = function(x) x*c(1,1/6)
                                    , loc = "endpoint" )
                    , adj = list( c(0,0) )  
                    , cnodes = c( "Mission", "Qualark" )
                    , tnodes = c( "Hells Gate", "Thompson", "Timber's House" )
                    , envData.dirs = c( "environment/DFO_TempFiles", "environment/WSC_DisFiles" )
                    , envData.files = c( "environment/tempDefns.csv", "environment/flowDefns.csv" )
                    , envData.varnames = c( "temp", "flow" ), year.env = 2002
                    , fishLocs = "fisheries/FishDefns.csv", fishOpens = "fisheries/FishOpens.csv"
                    , manPlanFile = "man/mP.csv"
			              , bneck = NULL
                    , cpars = list( list( type = c("norm", "norm.avg")
									    , par1 = c(600, 25), par2 = c(30, 10)
			                            , whichState = c(1,1), whichKeep = list(0, 1:14)
				                        , pfunc = pfunc.cTwT, pfpars = 0.5 ) )
                    , enterProps = list( c( 0.3, 0.7 ) )
                    , sc = 0.5, cpVec = 1:8, cpAll = NULL, cpVals = -1:8
                    , pNoBOTS = 0, natM = 0, stoch.nat = TRUE, stoch.fish = TRUE
                    , obsDesignFile = "obs/obsDesign.csv", out.file = "outdf.txt"
                    , speedRatio = 20, envRatio = 0.5, maxrows = 1e6, YAB = FALSE
			        , saveBOTS = FALSE, saveTags = FALSE
			              , seed = 999
                    )
                
{

set.seed( seed )
# Write column names to output file (DON'T TOUCH THIS)
colTF <- TRUE
# Create an empty observation object to append observations to
obs <- list()
# Make a cluster, if necessary
if( is.null( cl ) ){
  if( nProcs > 1 ){
    cl <- makeSOCKcluster( rep.int( "localhost", nProcs ) )
    clusterSetupRNGstream ( cl, seed = rep( seed + 1, nProcs ) )
    clusterEvalQ( cl, library(FSmod) )
  }
}else{
  nProcs <- length( cl )
  clusterSetupRNGstream ( cl, seed = rep( seed + 1, nProcs ) )
  clusterEvalQ( cl, library(FSmod) )
}

# FLAGS, etc.
# nProcs: the number of processors to use
# plotTF: controls plotting
# buildX: controls whether to load an existing X, or build it from scratch
# yRead: suppresses calculating X, and reads y in from file
# loadY: controls whether to load an existing move.df$y, or build it from scratch
# spT.file: file with spawn timing data
# mvr.file: file with movement rate data
# N.file: file with numbers returning
# CUdefs.file: file with CU definitions
# mvdefs.file: file with movement rate definitions
# year: the year of the simulation (used with referencing some input data.frames)
# nT: Length of season (12 hr timestep, beginning June 1st)

# BOTS are Objects for Tracking States
# nBots: number of BOTS that each CU gets
# nStates: number of State variables the the BOTS track
# reachNodes.file: file defining the reach nodes
# reachDefs.file: file defining the reaches
# cnodes: the counting nodes (must be in reachNodes.file)
# tnodes: the tag receiver nodes (must be in reachNodes.file)
# envData.dirs: the relative path to the environmental data
# envData.files: files with the environmental data
# envData.varnames: the variable names of the environmental data
# HGrule: use the Hell's Gate passage limitation rule?
# HGpen: Penalty that creates the HG bottleneck - the bigger the value, the more bottleneck occurs  
# cpars: Vector list of cumulative effects parameters, recycled if necessary
# sc: Vector of jump "scale" parameters, recycled if necessary
# pNoBOTS: Vector of probabilities of death for fish in reaches without BOTS (recycled by stockParsCreate1)
# natM: Underlying natural mortality rate
# stoch.nat: Enable stochastic natural mortality if TRUE
# stoch.fish: Enable stochastic catch if TRUE

# Read in Reach information
# Places a.k.a "nodes"
reachNodes <- read.csv( reachNodes.file, comment.char = "#", stringsAsFactors = FALSE, header = TRUE )
reachNodes[,2] <- as.numeric( reachNodes[,2] )
# Reaches - sections between nodes
reachDefs <- read.csv( reachDefs.file, comment.char = "#", strip.white = TRUE, colClasses = "character", header = FALSE )
# Reformat reaches to a list
reaches <- list()
for( r in 1:nrow( reachDefs ) ){
	reaches[[r]] <- as.integer( eval( parse( text = reachDefs[r,2] ) ) )
	if( any( is.na( reaches[[r]] ) ) ) stop( paste( "Reach definition", reachDefs[r,1], "parsing failed" ) )
}
names( reaches ) <- reachDefs[,1]


# Create river object with slots for flow, temperature, and stocks
reachid <- min( unlist( reaches ) ) : max( unlist( reaches ) )
nReach <- length( reachid )
if( length( unique( unlist( reaches ) ) ) != nReach ) warning( "The reach numbers you gave me are not contiguous." )


# Build the retpars file if necessary
if( is.null(retdist.file) ){
  cat( "Attempting to build the timing distributions...\n" )
  # Read in the retpars.file
  rpraw <- read.csv( retpars$file )
  # Use retpars.func to build the returns matrix
  rpars <- data.frame( CU = rpraw[,retpars$CU.col]
        , loc = rep( retpars$loc, length.out = nrow( rpraw ) )
        , p = t( apply( as.matrix(rpraw[,retpars$par.col]), 1, retpars$par.tran) )
        , stringsAsFactors = FALSE )
  rpars <- na.omit( rpars )
  dens <- matrix( 0., nrow = nrow(rpars), ncol = nT
                , dimnames = list( rpars$CU, paste("T",1:nT,sep=".") ) )
  for( r in 1:nrow(dens) ) dens[r,] <- retpars$func( 1:nT, as.numeric( rpars[r,-(1:2)] ) )
  # Create the retdist.file file and call it CU/retdist-'seed'.csv
  retd <- data.frame( CU = rpars$CU, loc = rpars$loc, dens )
  retdist.file <- paste("CU/retdist-", seed, ".csv", sep="")
  write.csv( retd, file = retdist.file, row.names = FALSE )
  cat( paste( "Timing distributions successfully built, written to ", retdist.file, "\n" ) )
}

#-----------------------------------------------------------------------------
# Set up the CU object with all the stocks
cat( "Attempting to build the CU object with movement rates, \n numbers, reaches, and other parameters.\n" )
spc1 <- .stockParsCreate1( moverates = mvr.file
	    	, N = N.file, CUdefs = CUdefs.file, mvDefs = mvdefs.file
        , retdist = retdist.file, adj = adj, year.N = year.N, reaches = reaches
        , reachid = reachid, nT = nT, nStates = nStates, keepStates = keepStates
        , minBots = 10, nBots = nBots, cumulPars = cpars, pNoBOTS = pNoBOTS
        , enterProps = enterProps, sc = sc, speedRatio = speedRatio
        , reachNodes = reachNodes )
# The CU object
CU <- spc1$CU
# The numbers returning
cuN <- spc1$cuN
# Number of CUs
nCU <- length( CU )
# The movement rates by CU and reach
moveRates <- spc1$moveRates
# The nodes that each CU goes past
for( i in 1:length( CU ) ){
  CU[[i]]$nodes <- reachNodes[ reachNodes[,2] %in% CU[[i]]$allReaches, ]
  CU[[i]]$nodes <- CU[[i]]$nodes[ order( CU[[i]]$nodes[,2] ), ]
}
# The names of the CUs
CUnames <- sapply( CU, FUN = function(x) x$CUname )
cat( "CU object successfully built. \n" )

#----------------------------------------------------------------------------
# Create the cutpoints object (CU-specific!)
if( is.null(cpAll) ){
	cpAll <- matrix( cpVec, nrow = length( reachid ), ncol = length( cpVec )
			, byrow = TRUE )
	colnames( cpAll ) <- paste( "cp", cpVec + 1, sep = "." )
	cpAll <- as.data.frame( cpAll )
	cpAll <- cbind( reach = reachid, cpAll )
}
for( i in 1:nCU ) CU[[i]]$cpAll <- cpAll




#-----------------------------------------------------------------------------
# Define the nodes with counting
cnodes <- reachNodes[ reachNodes[,1] %in% cnodes, 2 ]
for( i in 1:length( CU ) ){
  CU[[i]]$cnodes <- cnodes
  CU[[i]]$counts <- matrix( 0, nrow = nT, ncol = length( cnodes ), dimnames = list( NULL, reachNodes[ reachNodes[,2] %in% cnodes, 1 ] ) )
}

#-----------------------------------------------------------------------------
# Define the nodes with tag listening stations
tnodes <- reachNodes[ reachNodes[,1] %in% tnodes, 2 ]
for( i in 1:length( CU ) ) CU[[i]]$tnodes <- tnodes

#-----------------------------------------------------------------------------
# Read in the observation design
options( warn = -1 )
obsDesign <- try( read.csv( obsDesignFile, comment.char = "#", stringsAsFactors = FALSE, row.names = NULL, fill = FALSE ) )
if( class( obsDesign ) == "try-error" ) stop( "Failed to read in obsDesign \n" )

#-----------------------------------------------------------------------------
# Read in the in-season management plan
manPlan <- try( read.csv( manPlanFile, comment.char = "#", stringsAsFactors = FALSE, row.names = NULL, fill = FALSE ) )
if( class( manPlan ) == "try-error" ) stop( "Failed to read in manPlan \n" )
options( warn = 0 )

#-----------------------------------------------------------------------------                       
if( buildX == TRUE ){
  if( !yRead ){ stop( "We currently don't use a linear model for calculating 
movement rates.  If you are setting buildX to TRUE, then set 
yRead to TRUE as well (and possibly loadY to TRUE if the movement rates 
have not changed since the last FSmodRun call)." ) }

# Build the data frame for movement effects 
  move.df <- expand.grid( list( T = 1:nT , reach = reachid , CU = 1:nCU ) )
  move.df$reach <- as.factor( move.df$reach )
  move.df$T <- as.factor( move.df$T )
  move.df$CU <- as.factor( move.df$CU )
  move.df$flow <- NA
  move.df$temp <- NA

  envData <- .envBuild( dirt = envData.dirs , defs = envData.files, varnames = envData.varnames, nT = nT, year = year.env )
  save( envData, file = "envdata.rsv" )
  
# Plug the flow and temp data into move.df
  move.df$temp <- rep.int( envData$temp, nCU )
  move.df$flow <- rep.int( envData$flow, nCU )
  
  cat( "Done placing environmental data \n" )
  
  move.df <- .movedfTrim( CU, move.df ) 
  save( move.df, file = "movedf.rsv" )

# The movement formula
#  move.formula <- ~ CU + flow + temp:CU + reach
   move.formula <- ~ CU + reach

# The design matrices - one per CU is needed due to size limits?  YES.
  if( !yRead ){
    X <- model.matrix( move.formula, data = move.df )
    save( X, file = "Xdesign.rsv" )
  }
}  
 
    load( "envdata.rsv" )
    load( "movedf.rsv" )
	
  if( !yRead ){
    load( "Xdesign.rsv" )    
    eff.names <- attributes(X)$dimnames[[2]]

	# Create the beta vector...  
  }

#-----------------------------------------------------------------------------
# If we are reading in the movement rate from file...
if( yRead ){
  if( !loadY ){
	  cat( "Reading in movement rates from file...\n" )
  	move.df$y <- rep.int( NA, nrow( move.df ) )
	for( i in 1:nCU ){
		currCU <- as.character( CU[[i]]$CUname )
		cat("Getting movement rates for CU", currCU, "...")
	  for( j in CU[[i]]$allReaches ){
		move.df$y[ move.df$reach == j & move.df$CU == i ] <-
				moveRates$y[ as.character(moveRates$CU) == currCU & moveRates$reach == j ] / speedRatio + 0.5
	  }
	    cat( "Done. \n")
        }	
	save( move.df, file = "movedfY.rsv")
  }else{
  cat( "loadY = TRUE; using the movement rates from a previous run of FSmodRun...\n" )
  load( "movedfY.rsv" )
  # Check to make sure the number of CUs in movedfY.rsv
  # matches the number of CUs in this simulation
  # (this is a rough sanity check!)
  if( nlevels(move.df$CU)!=length(CU) ) stop( "The number of CUs in the movedfY.rsv file do not match the number of CUs in the CUdefs.file! Re-run with loadY = FALSE.")
  }
}
  
#-----------------------------------------------------------------------------
# The harvest plan is generated from control files using harvBuild()
cat( "Building the harvest rate matrix...\n" )
harv <- .harvBuild( fishLocs, fishOpens, reachid, nT )
cat( "Harvest rate matrix successfully built.\n" )

#-----------------------------------------------------------------------------
# Natural mortality
mortM <- matrix( natM, nrow = length( reachid ), ncol = nT , dimnames = list( paste( "Reach", reachid, sep = "" ), paste( "Time", 1:nT, sep = "" ) ) )

for( i in 1:nCU ) mortM[ max( unlist( CU[[i]]$reach ) ), ] <- 0.
# mortM[ , 100:nT] <- 1



#-----------------------------------------------------------------------------
# Return schedule to first areas
  # Going to use spc1$arrT$arrMats[[]]

  retSplit <- vector( length = nCU, mode = "list" )
  for( i in 1:nCU ) retSplit[[i]] <- vector( length = length( CU[[i]]$enterProps ), mode = "list" )
  retSplitBOT <- vector( length = nCU, mode = "list" )
  for( i in 1:nCU ) retSplitBOT[[i]] <- vector( length = length( CU[[i]]$enterProps ), mode = "list" )
    
  for( i in 1:nCU ){
	# The numbers returning via each path
	NbyPath <- cuN[[i]] * CU[[i]]$enterProps
	# A temp object holding the returns by timestep for some path
	temp <- numeric( length = nT )
	for( j in 1:length( CU[[i]]$enterProps ) ){
      temp <- round( spc1$arrT$arrMats[[j]][i,] / sum( spc1$arrT$arrMats[[j]][i,] )
		           * NbyPath[j] )
	  # Make sure the distribution sums to cuN[[i]] * CU[[i]]$enterProps
      temp[ which.max( temp ) ] <- temp[ which.max( temp ) ] + round( NbyPath[j] ) - sum( temp )		  
      retSplit[[i]][[j]] <- temp
	  # Now match up the BOTS
	  retSplitBOT[[i]][[j]] <- round( temp/max(sum(temp),1) * CU[[i]]$enterProps
	                           * nrow( CU[[i]]$bots ) * 0.95 )
    }
	# A final check to make sure the numbers sum up correctly
	mx <- which.max(CU[[i]]$enterProps)
	retSplit[[i]][[mx]][ which.max( retSplit[[i]][[mx]] ) ] <- 
       ( retSplit[[i]][[mx]][ which.max( retSplit[[i]][[mx]] ) ] + cuN[[i]] 
       - sum( unlist( retSplit[[i]] ) ) )
  }
  
#-----------------------------------------------------------------------------
# Adjust the river object to create bottlenecks
if( !is.null( bneck ) ){
  # Find the bottlenecks that are not time-specific
  bneckAllT <- bneck[ is.na( bneck$t ), ]
  # Save the bottlenecks that are time-specific
  bneckTsp <- bneck[ !is.na( bneck$t ), ]
  if( nrow( bneckAllT ) > 0 ){
    # Apply these non-time-specific bottlenecks before we start
    for( p in 1:nrow( bneckAllT ) ){
      # Find the correct CU (could be all CUs if NA)
      if( is.na( bneckAllT$CU[p] ) ){
	    for( i in 1:nCU ) CU[[i]]$cpAll <- .bn( CU[[i]]$cpAll, bneckAllT[p,], reaches, cpv = cpVals )
	  }else{
	    # Apply the bottleneck to this CU
	    j <- which( CUnames == bneckAllT$CU[p] )
	    CU[[j]]$cpAll <- .bn( CU[[j]]$cpAll, bneckAllT[p,], reaches, cpv = cpVals )
	  }
    }
  }
}


# Save the baseline cutpoints
cpAllCU <- vector( mode = "list", length = nCU )
for( i in 1:nCU ) cpAllCU[[i]] <- CU[[i]]$cpAll
# Flag to tell us which the cutpoints have been changed
cpChanged <- rep( FALSE, nCU )

#-----------------------------------------------------------------------------
# Simulation loop

  # movement effects (i.e. Xb )
    if( !yRead ){
	  y <- X%*%beta
      # append movement effects to move.df
      move.df$y <- y
    }


  for( t in 1:nT ){
	  
	# Adjust the cutpoints at this timestep if necessary
	if( !is.null( bneck ) ){
	  if( nrow( bneckTsp ) > 0 ){
		# Find the bottlenecks that are at this timestep
		bneckt <- bneckTsp[ bneckTsp$t == t, ]
		if( nrow( bneckt ) > 0 ){
			# Apply these bottlenecks
			for( p in 1:nrow( bneckt ) ){
				# Find the correct CU (could be all CUs if NA)
				if( is.na( bneckt$CU[p] ) ){
					for( i in 1:nCU ){
					  CU[[i]]$cpAll <- .bn( CU[[i]]$cpAll, bneckt[p,], reaches, cpv = cpVals )
					  cpChanged[i] <- TRUE
				    }
				}else{
					# Apply the bottleneck to this CU
					j <- which( CUnames == bneckt$CU[p] )
					CU[[j]]$cpAll <- .bn( CU[[j]]$cpAll, bneckt[p,], reaches, cpv = cpVals )
					cpChanged[j] <- TRUE
				}
			}
		}
	  }
	}
	
      
      # Get this timestep's subset of the movement effects
        y.curr <- move.df[ move.df$T == t , ]

      # Move the fish and BOTS
        if( nProcs > 1 ) CU <- parLapply( cl, x = CU, fun = .moveCL, y = y.curr, cpV = cpVals, allReaches = reachid, t = t )
        if( nProcs == 1 ) CU <- lapply( X = CU, FUN = .moveCL, y = y.curr, cpV = cpVals, allReaches = reachid, t = t )
       
      for( i in 1:nCU ){

      # Remove fish and BOTS and tags that have reached the spawning grounds  
        CU[[i]] <- .spawn( CU[[i]], t, saveBOTS = saveBOTS, saveTags = saveTags )
            
      # Put this time period's worth of BOTS on the map  
#        if( retJSBOT[[i]][t] != 0 ){
#          newBots <- .retF( retJSBOT[[i]][t], reachids = CU[[i]]$reach[[1]], node = reachNodes$REACHID[ reachNodes$NODES == "Johnstone Strait" ], allReaches = reachid, pars = list( mr = CU[[i]]$retpars.mr[1] ) )
#          CU[[i]]$bots <- .putBots( CU[[i]]$bots, newBots, path = 1 )
#        }
#        if( retJFBOT[[i]][t] != 0 ){
#          newBots <- .retF( retJFBOT[[i]][t], reachids = CU[[i]]$reach[[2]], node = reachNodes$REACHID[ reachNodes$NODES == "Juan de Fuca Strait" ], allReaches = reachid, pars = list( mr = CU[[i]]$retpars.mr[1] ) )
#          CU[[i]]$bots <- .putBots( CU[[i]]$bots, newBots, path = 2 )
#        }
        
        for( j in 1:length( retSplitBOT[[i]] ) ){
          if( retSplitBOT[[i]][[j]][t] != 0 ){
            newBots <- .retF( retSplitBOT[[i]][[j]][t], reachids = CU[[i]]$reach[[j]], node = CU[[i]]$reach[[j]][1], allReaches = reachid, pars = list( mr = spc1$arrT$mr[i] ) )
            CU[[i]]$bots <- .putBots( CU[[i]]$bots, newBots, path = j )
          }
          if( retSplit[[i]][[j]][t] != 0 ){
            CU[[i]]$N[,j] <- CU[[i]]$N[,j] + .retF( retSplit[[i]][[j]][t], reachids = CU[[i]]$reach[[j]], node = CU[[i]]$reach[[j]][1], allReaches = reachid, pars = list( mr = spc1$arrT$mr[i] ) )
          }
        }
        
      # Put this time period's worth of returns on the map  
#        if( retJS[[i]][t] != 0 ) CU[[i]]$N[,1] <- CU[[i]]$N[,1] + .retF( retJS[[i]][t], reachids = CU[[i]]$reach[[1]], node = reachNodes$REACHID[ reachNodes$NODES == "Johnstone Strait" ], allReaches = reachid, pars = list( mr = CU[[i]]$retpars.mr[1] ) )
#        if( retJF[[i]][t] != 0 ) CU[[i]]$N[,2] <- CU[[i]]$N[,2] + .retF( retJF[[i]][t], reachids = CU[[i]]$reach[[2]], node = reachNodes$REACHID[ reachNodes$NODES == "Juan de Fuca Strait" ], allReaches = reachid, pars = list( mr = CU[[i]]$retpars.mr[1] ) )
        
  
      # For output, keep track of abundance, catches, and natural mortality of each CU by location
        outcurr <- cbind( t, i, reachid, rowSums( CU[[i]]$N ) )
        dimnames( outcurr ) <- list( NULL, c( "t", "CU", "reachid", "N" ) )
        
      # Calculate natural mortality and apply
   
      # Update BOTS attributes
        CU[[i]]$bots <- .botUpdate( CU[[i]]$bots, deltaAtt = envRatio * envData[ envData$T == t, 3:(2+nStates) ]
		                       , keepRecent = keepStates, currentVals = envData[ envData$T == t, 3:(2+nStates) ] )
      # Update tags attributes
        if( nrow( CU[[i]]$tags ) > 0 ){ 
			CU[[i]]$tags <- .tagsUpdate( CU[[i]]$tags, deltaAtt = envRatio * envData[ envData$T == t, 3:(2+nStates) ]
                               , keepRecent = keepStates, currentVals = envData[ envData$T == t, 3:(2+nStates) ] ) 
		}

      # Calculate probability of death parameters
      #  pdie <- .mortCalc( CU[[i]]$bots, pars = list( type = "norm", par1 = CU[[i]]$cumulPars$normMu, par2 = CU[[i]]$cumulPars$normSD, whichState = 1 ), allReaches = reachid )
        pdie <- .mortCalc( CU[[i]]$bots, pars = CU[[i]]$cumulPars, allReaches = reachid )

      # Apply mortality to fish and tags
        CU[[i]]$N <- .killFish( N = CU[[i]]$N, kill = pdie$bbpars, reachlist = CU[[i]]$reach, stoch = stoch.nat, pNoBOTS = CU[[i]]$pNoBOTS )
        CU[[i]]$N <- .killFish2( N = CU[[i]]$N, kill = mortM[, t], stoch = stoch.nat )
      # if( nrow( CU[[i]]$tags ) > 0 ) CU[[i]]$tags <- .killTags( tags = CU[[i]]$tags, pars = list( type = "norm", par1 = CU[[i]]$cumulPars$normMu, par2 = CU[[i]]$cumulPars$normSD, whichState = 1 ) )
		if( nrow( CU[[i]]$tags ) > 0 ){
			tagtemp <- .killTags( tags = CU[[i]]$tags, pars = CU[[i]]$cumulPars )
			CU[[i]]$tags <- tagtemp$bots
			killTab <- tabulate( tagtemp$killLoc, nbin = nrow(CU[[i]]$N) )
			# if( !(all(tagtemp$killLoc %in% CU[[i]]$allReaches)) & any(killTab!=0) ) browser()
			m <- outcurr[ , colnames( outcurr ) == "N" ] - rowSums( CU[[i]]$N ) + killTab
		}else{
			m <- outcurr[ , colnames( outcurr ) == "N" ] - rowSums( CU[[i]]$N )
		}
		
      # Apply mortality to BOTS
      # kBots <- .killBOTS( CU[[i]]$bots, pars = list( type = "norm", par1 = CU[[i]]$cumulPars$normMu, par2 = CU[[i]]$cumulPars$normSD, whichState = 1 ) )
        kBots <- .killBOTS( CU[[i]]$bots, pars = CU[[i]]$cumulPars )
        CU[[i]]$bots <- kBots$bots
        CU[[i]]$deadBots <- CU[[i]]$deadBots + kBots$nKill

      # Calculate fishing mortality and apply
        CU[[i]]$N <- .killFish2( N = CU[[i]]$N, kill = harv$harvM[, t], stoch = stoch.fish )
        C <- outcurr[ , colnames( outcurr ) == "N" ] - m - rowSums( CU[[i]]$N )

      # Apply fishing mortality to BOTS
        kBots <- .killBOTS( CU[[i]]$bots, pars = list( type = "knownRate", rate = harv$harvM[, t] ) )
        CU[[i]]$bots <- kBots$bots
        CU[[i]]$deadBots <- CU[[i]]$deadBots + kBots$nKill
                      
      # Repopulate BOTS
      if( CU[[i]]$deadBots > ( 0.2 * nrow( CU[[i]]$bots ) ) ){
        CU[[i]]$bots <- .budBOTS( CU[[i]]$bots, pars = list( type = 3, minBots = NULL, growFrac = 0.2 ) )
        CU[[i]]$deadBots <- 0
      }
      
      # Save the stuff to the output object
      # There will be a maximum number of rows in the output object
      # If the amount of output exceeds the number of rows, then it will have
      #   to be dumped to a file.
        if( !exists( "out" ) ){
          outrows <- nCU * nT * nrow( outcurr )
          # Check to see if the required number of rows exceeds maxrows
          needToSave <- outrows > maxrows
          # Calculate the appropriate number of rows for output        
          if( needToSave ){
            outrows <- floor( maxrows / nrow( outcurr ) ) * nrow( outcurr )
            cat( "The number of rows of output exceeds maxrows... out.df will be NULL \n" )
          }
          # Make a fresh output matrix  
          out <- matrix( NA, nrow = outrows, ncol = ncol( outcurr ) + 2 + ncol(pdie$props) )
          dimnames( out ) <- list( NULL, c( colnames( outcurr ), "m", "C", paste( "P", 1:ncol(pdie$props), sep="." ) ) )
          rowcurr <- 1:nrow( outcurr )
        }
        out[ rowcurr , ] <- cbind( outcurr, m, C, pdie$props )
        # If we need to save output and we have filled up "out", then write
        if( max( rowcurr ) == outrows & needToSave ){
          write.table( out, file = out.file, append = !colTF
                      , row.names = FALSE, col.names = colTF )
          # Scrap the out object so that it gets remade at the next iteration
          rm( out )
          colTF <- FALSE
        }
        rowcurr <- rowcurr + nrow( outcurr )
    } # End for i in nCU

    # Call the observation routine (put here so that we are out of CU loop)

    if( nrow(obsDesign) > 0 ) .doObs( obsDesign = obsDesign, t = t )             

	# Call the in-season management routine
  	if( nrow(manPlan) > 0 ) .doMan( manPlan =  manPlan )
	
	# Revert to the baseline cpAll values if necessary
    if( any( cpChanged ) ){
		for( j in which( cpChanged ) ) CU[[j]]$cpAll <- cpAllCU[[j]]
		cpChanged <- rep( FALSE, nCU )
	}
	
    } # End of timestep loop

  # Last write.table for the last bit of output
  if( needToSave ){
    write.table( na.omit(out), file = out.file, append = TRUE
                , row.names = FALSE, col.names = FALSE )
    out <- NULL
  }
  
if( nProcs > 1 ) stopCluster( cl )

if( plotTF ){
  if( is.null( plotPars$plotBOTS ) ) plotPars$plotBOTS <- FALSE
  if( is.null( plotPars$nPerPage ) ) plotPars$nPerPage <- 4
  if( needToSave ){  
    plotFSmodOut( fn = out.file, CU = CU, cuN = cuN
                 , plotBOTS = plotPars$plotBOTS
                 , whichCU = plotPars$whichCU
                 , nPerPage = plotPars$nPerPage
                 , pdfname = plotPars$pdfname )
  }else{
    plotFSmodOut( out.df = as.data.frame(out), CU = CU, cuN = cuN
                 , plotBOTS = plotPars$plotBOTS
                 , whichCU = plotPars$whichCU
                 , nPerPage = plotPars$nPerPage
                 , pdfname = plotPars$pdfname )
  }
}

if( plotTFinteract ){
  if( needToSave ){  
    plotFSmodOut.interactive( fn = out.file, CU = CU, cuN = cuN, type = plotPars$itype )
  }else{
    plotFSmodOut.interactive( out.df = as.data.frame(out)
                            , CU = CU, cuN = cuN,  type = plotPars$itype )
  }
}

list( out.df = out, CU = CU, cuN = cuN, harv = harv, moveRates = moveRates, obs = obs )
}