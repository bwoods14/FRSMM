.First.lib <- function( lib, pkg ){
  library.dynam("FSmod", pkg, lib)
  cat("------------------------------------------------------------------- \n")
  cat("If you want to use the configuration and data files supplied with \n")
  cat("this package, you need to copy them from the installation directory \n")
  cat("to your working directory. \n")
  cat("There is a convenience function included called getFSmodFiles() for \n")
  cat("this purpose. \n")
  cat("See ?getFSmodFiles and ?FSmod \n")
  cat("------------------------------------------------------------------- \n")
}

