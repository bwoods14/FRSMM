# pdfacro.r
# code to stand in for pdf() that kills acrobat reader if you need to,
#   or opens the pdf for you once you're done making it.
# this code only works in Windoze, which should be fine, because there are better pdf readers for other systems.
# Author: Aaron Springford
#
# *** This code should ideally use DDE, but I couldn't get it to work using 'tk2dde' in tcltk2 ***

pdfacro <- function( file = ifelse(onefile, "Rplots.pdf", "Rplot%03d.pdf"), ... )
{ 
  # This function takes all of the arguments of pdf(), namely:
  #  width, height, onefile, family, title, fonts, version, paper, 
  #  encoding, bg, fg, pointsize, pagecentre, colormodel, useDingbats, 
  #  useKerning

  # Determine if we are in windoze
    if( .Platform$OS.type == "windows" ){
      # Kill any Adobe reader that already has the document open
      shell( paste( "taskkill /F /FI \"WINDOWTITLE eq ", file, "*\" /IM acrord32.exe", sep = "" ), wait = FALSE )
      shell( paste( "taskkill /F /FI \"WINDOWTITLE eq ", file, "*\" /IM Acrobat.exe", sep = "" ), wait = FALSE )
    }# end if windows
    Sys.sleep( 0.5 )
    pdf( file, ... )
}

dev.off.acro <- function( filename )
{
  # This function will close the current device and if it is a pdf and show it in Windoze's pdf viewer 
    if( names( dev.cur() ) == "pdf" ){
      dev.off()
      if( .Platform$OS.type == "windows" ){
        # Open the file
        shstr <- paste( getwd(), filename, sep="/" )
        if( length( grep( ":", filename ) ) ) shstr <- filename
        a <- shell.exec( shQuote( shstr ) )
        if( length( a ) > 0 ) cat( "Trouble displaying your pdf - check the filename and pathtoacro values \n" )
      }# end if windows
    }else{
      dev.off()
      cat( "The device is not a .pdf - I won't be displaying it for you... \n" )
    }
}