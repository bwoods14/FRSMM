# Jumptest.r

.jump <- function( location, scale, cp, cpV ) .Call( "jump", as.double( location ), as.double( scale ), as.double( cp ), as.integer( cpV ), PACKAGE = "FSmod" )

.jumpMulti <- function( n, location, scale, cp, cpV ){
  # This is the large sample version of jump
  # It makes use of the rmultinom() function rather than n rlogis() draws
  ##################################################
  n <- as.integer( n ); location <- as.double( location ); cp <- as.double( cp ); cpV <- as.integer( cpV )
  # Calculate the probability vector
  cumProbs <- 1 - c( plogis( location - cp, scale = scale ), 0 )
  probs <- cumProbs[1]
  for( i in 2:length( cpV ) ) probs[i] <- cumProbs[i] - cumProbs[i-1]
  # Generate jumps
  as.vector( rmultinom( 1, n, prob = probs ), mode = "integer" )
}

.putJump <- function( jumps, cpV, reaches, currReach, allReaches ) .Call( "placeJ", as.integer( jumps ), as.integer( cpV ), as.integer( reaches ), as.integer( currReach ), as.integer( allReaches ), PACKAGE = "FSmod" )

.doJump <- function( n, location, scale, cp, cpV, reaches, currReach, allReaches ){
  # location: logistic regression y value
  # scale: the scale parameter for logistic regression
  # cp: vector of cutpoints defining jumping intervals
  # cpV: vector of jumping distances corresponding to jumping intervals
  # reaches: vector of the reaches comprising the path
  # currReach: the current "jump-from" reach
  # allReaches: the entire river
  #################################################
  if( ( length( cp ) + 1 ) != length( cpV ) ) stop( "doJump: The length of cp is not one less than cpV!" )
  if( n < 5 ){
    # generate the jumping distribution
    jumps <- .jump( rep.int( location, n ), scale, cp, cpV )
  }else{
    jumps <- .jumpMulti( n, location, scale, cp, cpV )
  }
    # place the jumps
    .putJump( jumps, cpV, reaches, currReach, allReaches )
    # return the next timestep position vector
}

# This function jumps bots one at a time
.botJump <- function( location, scale, cp, cpV, reaches, currReach ){
  reaches[ min( max( which( reaches == currReach ) + sum( cpV * .jump( location, scale, cp, cpV ) ) , 1 ), length( reaches ) ) ]  
}